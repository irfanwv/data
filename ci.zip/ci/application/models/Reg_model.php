<?php
class Reg_model extends CI_Model {

        public $name;
        public $email;
        public $address;

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
        }



        public function insert_entry($data)
        {
		//print_r($data);
             $rslt =   $this->db->insert('reg', $data);
	     echo $rslt;
        }


}
