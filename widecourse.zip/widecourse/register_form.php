<style>
    #signupform .form-row input{
        width: 100%;
        margin-bottom: 15px;
        padding: 10px 5px;
    }
    
</style>

<div id="register-form" class="widecolumn">
    <?php if ( $attributes['show_title'] ) : ?>
        <h3><?php _e( 'Register', 'personalize-login' ); ?></h3>
    <?php endif; ?>
 
    <form id="signupform" action="<?php //echo wp_registration_url(); ?>" method="post">
            <div class="form-row">
            <label for="username"><?php _e( 'Username', 'personalize-login' ); ?> <strong>*</strong></label>
            <div><input type="text" name="username" id="username"></div>
        </div>
        <div class="form-row">
            <label for="email"><?php _e( 'Email', 'personalize-login' ); ?> <strong>*</strong></label>
            <div><input type="text" name="email" id="email"></div>
       </div>
        <div class="form-row">
            <label for="first_name"><?php _e( 'First name', 'personalize-login' ); ?></label>
            <div><input type="text" name="first_name" id="first-name"></div>
        </div>
        <div class="form-row">
            <label for="last_name"><?php _e( 'Last name', 'personalize-login' ); ?></label>
            <div><input type="text" name="last_name" id="last-name"></div>
        </div>
        <div class="form-row">
            <label for="password"><?php _e( 'Password', 'personalize-login' ); ?></label>
            <div><input type="text" name="password" id="password"></div>
        </div>
        <p class="form-row">
            <?php //_e( 'Note: Your password will be generated automatically and sent to your email address.', 'personalize-login' ); ?>
        </p>
        <p class="signup-submit">
            <input type="submit" name="submit" class="register-button"
                   value="<?php _e( 'Register', 'personalize-login' ); ?>"/>
        </p>
    </form>
</div>

