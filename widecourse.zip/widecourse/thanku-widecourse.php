<?php
//ThankYou page
get_header();

    if($_GET['sbn'] != '')
    {
        global $wpdb;
        $qrry = "SELECT * FROM ".$wpdb->prefix."course_book WHERE sNo=".$_GET['sbn'];
        $results = $wpdb->get_row( $qrry );
        
        
        $course = get_post( $results->course_id );
        
        //$user = get_user_by('id', $key['user_id']);
        //
        //$usrArray['name'] = $user->user_login;
        if (function_exists('email')) {
            
            email($results->course_id, $results->user_id);
	 // echo $ack = email(1218, 26);
            
        }
    
    }

  ?>
  
		<div id="primary" class="content-area">
			<div id="content" class="site-content" role="main">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'content', 'page' ); ?>
                    
                    <p>Thank you for reserving a spot in <?php echo $course->post_title; ?> starting on <?php echo get_post_meta($results->course_id, "widecourse_date", true); ?>.</p>
                    <p>You will be receiving an email with the details.</p>

					<!--<?php comments_template( '', true ); ?>
                                    
				<?php endwhile; // end of the loop. ?>

			</div><!-- #content .site-content -->
		</div><!-- #primary .content-area -->
<?php //wp_reset_query(); ?>
<?php get_footer(); ?>