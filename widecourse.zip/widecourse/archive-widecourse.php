<?php get_header(); ?>
<style>
    .odd-tr { background-color: #EFEFEF; }
    .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
        padding: 8px;
        line-height: 1.42857143;
        vertical-align: top;
        border-top: 1px solid #ddd;
        }
    .courselink { color: #00a1e4; text-decoration: underline; }
    a.courselink:hover { color: #00a1e4; text-decoration: none;}
    a.courselink:visited { color: #00a1e4; text-decoration: underline; }
</style>
<section id="primary">
    <div id="content" role="main" style="width: 100%">
    <?php if ( have_posts() ) : ?>
        <header class="page-header">
            <h1 class="page-title">Course List</h1>
        </header>
        <table class="table table-striped">
            <!-- Display table headers -->
            <tr>
                <th style="width: 200px"><strong>Title</strong></th>
                <th><strong>Course Category</strong></th>
                <th><strong>Course Seat</strong></th>
                <th><strong>Course Duration</strong></th>
                <th><strong>Course Date</strong></th>
               <!-- <th><strong>Course Legislation</strong></th>-->
            </tr>
            <!-- Start the Loop -->
            <?php $i = 1; ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <!-- Display review title and author -->
                <tr <?php if($i%2) { echo 'class="odd-tr"'; } ?>>
                    <td><a href="<?php the_permalink(); ?>" class="courselink">
                    <?php the_title(); ?></a></td>
                    <td><?php the_terms( $post->ID, 'course-categories' ,  ' ' ); //echo esc_html( get_post_meta( get_the_ID(), 'widecourse_date', true ) ); ?></td>
                     <td><?php echo esc_html( get_post_meta( get_the_ID(), 'widecourse_seat', true ) ); ?></td>
                      <td><?php echo esc_html( get_post_meta( get_the_ID(), 'widecourse_duration', true ) ); ?></td>
                       <td><?php echo esc_html( get_post_meta( get_the_ID(), 'widecourse_date', true ) ); ?></td>
                       <!-- <td><?php echo esc_html( get_post_meta( get_the_ID(), 'widecourse_legislation', true ) ); ?></td>-->
                </tr>
            <?php $i++; ?>
            <?php endwhile; ?>
 
            <!-- Display page navigation -->
 
        </table>
        <?php global $wp_query;
        if ( isset( $wp_query->max_num_pages ) && $wp_query->max_num_pages > 1 ) { ?>
            <nav id="<?php echo $nav_id; ?>">
                <div class="nav-previous"><?php next_posts_link( '<span class="meta-nav">&larr;</span> Older reviews'); ?></div>
                <div class="nav-next"><?php previous_posts_link( 'Newer reviews <span class= "meta-nav">&rarr;</span>' ); ?></div>
            </nav>
        <?php };
    endif; ?>
    </div>
</section>
<br /><br />
<?php get_footer(); ?>