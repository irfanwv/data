<?php

    global $wpdb;
    $table_name = $wpdb->prefix . 'course_book'; // do not forget about tables prefix
        
    $search=$_REQUEST['search'];
    
        
    $per_page = 10; // constant, how much records will be shown per page
    // $limit = 5; // number of rows in page
        
    $columns = $this->get_columns();
    $hidden = array();
    $sortable = $this->get_sortable_columns();
        
    // here we configure table headers, defined in our methods
    $this->_column_headers = array($columns, $hidden, $sortable);
        
    // [OPTIONAL] process bulk action if any
    $this->process_bulk_action();
               
    // will be used in pagination settings
    if(isset($_REQUEST['search']))
    {
        $total_items = $wpdb->get_var("SELECT COUNT(sNo) FROM $table_name where `pro_name` LIKE '%".$search."%'");
    }
    else
    {
        $total_items = $wpdb->get_var("SELECT COUNT(sNo) FROM $table_name");
    }

       
    $pagenum = isset($_REQUEST['paged']) ? max(0, intval($_REQUEST['paged']) ) : 1;
    
    $offset = ( $pagenum - 1 ) * $per_page;
    $end_limit= ($pagenum)*($per_page);
    //$num_of_pages = ceil( $total_items / $per_page );
       
    $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'sNo';
    $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'asc';
        
 
    if(isset($_REQUEST['search']))// seacrh using textbox
    {
        $this->items = $wpdb->get_results($wpdb->prepare("Select * from $table_name where `user_id` LIKE %s OR `course_id` LIKE %s ORDER BY $orderby $order LIMIT %d OFFSET %d","%$search%","%$search%", $per_page, $paged), ARRAY_A);
    }
    elseif(!empty($_POST['cat_sort']))// search using cat dropdown
    {
        $this->items = $wpdb->get_results($wpdb->prepare("Select * from $table_name where `category_id`=$cat_sort ORDER BY user_id asc LIMIT %d OFFSET %d", $per_page, $paged), ARRAY_A);
    }
    else
    {          
        //$array = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name LIMIT $offset, $end_limit"), ARRAY_A);
	$array = $wpdb->get_results(("SELECT * FROM $table_name LIMIT $offset, $end_limit"), ARRAY_A);
	
	$usrArrays = array();
	foreach($array as $key)
	{
	    $post = get_post( $key['course_id'] );
	    $user = get_user_by('id', $key['user_id']);
	    
	    $usrArray['name'] = $user->user_login;
	    $usrArray['course_name'] = $post->post_title;
	    $usrArray['course_id'] = $key['course_id'];
	    $usrArray['booking_date'] = date("d-m-Y", strtotime($key['booking_date']));
	    $usrArrays[] = $usrArray;
	}
	
	$this->items = $usrArrays;
	}
       
        
    $this->set_pagination_args(array(
        'total_items' => $total_items, // total items defined above
        'per_page' => $per_page, // per page constant defined at top of method
        'total_pages' => ceil($total_items / $per_page) // calculate pages count
    ));
         