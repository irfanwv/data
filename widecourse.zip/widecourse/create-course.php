<?php

add_action( 'admin_init', 'my_admin' );

function my_admin() {
    add_meta_box( 'widecourse_meta_box',
        'Course Details',
        'display_widecourse_meta_box',
        'widecourse', 'normal', 'high'
    );
}


function display_widecourse_meta_box( $widecourse ) {
    // Retrieve the widecourse related information
	$widecourse_date = esc_html( get_post_meta( $widecourse->ID, 'widecourse_date', true ) );
	$widecourse_date_close = esc_html( get_post_meta( $widecourse->ID, 'widecourse_date_close', true ) );
	$widecourse_frequency = esc_html( get_post_meta( $widecourse->ID, 'widecourse_frequency', true ) );
	$widecourse_duration = esc_html( get_post_meta( $widecourse->ID, 'widecourse_duration', true ) );
	$widecourse_fee = esc_html( get_post_meta( $widecourse->ID, 'widecourse_fee', true ) );
	$widecourse_fee_ini = esc_html( get_post_meta( $widecourse->ID, 'widecourse_fee_ini', true ) );
	$widecourse_seat = esc_html( get_post_meta( $widecourse->ID, 'widecourse_seat', true ) );
   
    ?>
    <table>
        <tr>
            <td style="width: 100%">Date</td>
            <td><input type="text" size="80" name="widecourse_date" value="<?php echo $widecourse_date; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Registration Close Date</td>
            <td><input type="text" size="80" name="widecourse_date_close" value="<?php echo $widecourse_date_close; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Class Frequency</td>
            <td><input type="text" size="80" name="widecourse_frequency" value="<?php echo $widecourse_frequency; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Course Duration</td>
            <td><input type="text" size="80" name="widecourse_duration" value="<?php echo $widecourse_duration; ?>" /></td>
            
        </tr>
        <tr>
            <td style="width: 100%">Course Fees</td>
            <td><!--<textarea name="widecourse_description" id="widecourse_description" cols="50" rows="1"><?php echo $widecourse_description; ?></textarea>-->
            <input type="text" size="80" name="widecourse_fee" value="<?php echo $widecourse_fee; ?>" />
            </td>
        </tr>
        <tr>
            <td style="width: 100%">Reservation Fees</td>
            <td><!--<textarea name="widecourse_description" id="widecourse_description" cols="50" rows="1"><?php echo $widecourse_description; ?></textarea>-->
            <input type="text" size="80" name="widecourse_fee_ini" value="<?php echo $widecourse_fee_ini; ?>" />
            </td>
        </tr>
        <tr>
            <td style="width: 100%">Course Seat</td>
            <td><input type="text" size="80" name="widecourse_seat" value="<?php echo $widecourse_seat; ?>" /></td>
            
        </tr>
    </table>
    <?php
}

add_action( 'save_post', 'add_widecourse_fields', 10, 2 );

function add_widecourse_fields( $widecourse_id, $widecourse ) {
    // Check post type for our widecourses
    if ( $widecourse->post_type == 'widecourse' ) {
        // Store data in post meta table if present in post data
	if ( isset( $_POST['widecourse_date'] ) && $_POST['widecourse_date'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_date', $_POST['widecourse_date'] );
        }
	if ( isset( $_POST['widecourse_date_close'] ) && $_POST['widecourse_date_close'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_date_close', $_POST['widecourse_date_close'] );
        }
        if ( isset( $_POST['widecourse_frequency'] ) && $_POST['widecourse_frequency'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_frequency', $_POST['widecourse_frequency'] );
        }
        if ( isset( $_POST['widecourse_duration'] ) && $_POST['widecourse_duration'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_duration', $_POST['widecourse_duration'] );
        }
	if ( isset( $_POST['widecourse_fee'] ) && $_POST['widecourse_fee'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_fee', $_POST['widecourse_fee'] );
        }
	if ( isset( $_POST['widecourse_fee_ini'] ) && $_POST['widecourse_fee_ini'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_fee_ini', $_POST['widecourse_fee_ini'] );
        }
	if ( isset( $_POST['widecourse_seat'] ) && $_POST['widecourse_seat'] != '' ) {
            update_post_meta( $widecourse_id, 'widecourse_seat', $_POST['widecourse_seat'] );
        }
    }
}

add_filter( 'manage_edit-widecourse_columns', 'my_columns' );

function my_columns( $columns ) {
    $columns['widecourse-date'] = 'Start Date';
    $columns['widecourse-duration'] = 'Duration';
    $columns['widecourse-fee'] = 'Full Fees';
    $columns['widecourse-fee-ini'] = 'Reservation Fees';
    $columns['widecourse-seat'] = 'Seat';
    $columns['widecourse-date-close'] = 'Close Date';
    unset( $columns['comments'] );
    return $columns;
}

	
 add_action( 'manage_posts_custom_column', 'populate_columns' );

function populate_columns( $column ) {
    if ( 'widecourse-date' == $column ) {
		$widecourse_date = esc_html( get_post_meta( get_the_ID(), 'widecourse_date', true ) );
        
        echo $widecourse_date;
    }
    elseif ( 'widecourse-fee' == $column ) {
        $widecourse_fee = esc_html( get_post_meta( get_the_ID(), 'widecourse_fee', true ) );
        echo $widecourse_fee;
    }
    elseif ( 'widecourse-fee-ini' == $column ) {
        $widecourse_fee_ini = esc_html( get_post_meta( get_the_ID(), 'widecourse_fee_ini', true ) );
        echo $widecourse_fee_ini;
    }
    elseif ( 'widecourse-duration' == $column ) {
        $widecourse_duration = esc_html( get_post_meta( get_the_ID(), 'widecourse_duration', true ) );
        echo $widecourse_duration;
    }
    elseif ( 'widecourse-seat' == $column ) {
        $widecourse_duration = esc_html( get_post_meta( get_the_ID(), 'widecourse_seat', true ) );
        echo $widecourse_duration;
    }
    elseif ( 'widecourse-date-close' == $column ) {
        $widecourse_duration = esc_html( get_post_meta( get_the_ID(), 'widecourse_date_close', true ) );
        echo $widecourse_duration;
    }
} 

add_action( 'restrict_manage_posts', 'my_filter_list' );

function my_filter_list() {
    $screen = get_current_screen();
    global $wp_query;
    if ( $screen->post_type == 'widecourse' ) {
        wp_dropdown_categories( array(
            'show_option_all' => 'Show All Widecourse Categories',
            'taxonomy' => 'widecourse-categories',
            'name' => 'widecourse-categories',
            'orderby' => 'name',
            'selected' => ( isset( $wp_query->query['widecourse-categories'] ) ? $wp_query->query['widecourse-categories'] : '' ),
            'hierarchical' => false,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ) );
    }
}


add_filter( 'parse_query','perform_filtering' );

function perform_filtering( $query ) {
    $qv = &$query->query_vars;
    if ( ( $qv['widecourse-categories'] ) && is_numeric( $qv['widecourse-categories'] ) ) {
        $term = get_term_by( 'id', $qv['widecourse-categories'], 'widecourse-categories' );
        $qv['widecourse-categories'] = $term->slug;
    }
}


?>