<?php

    

if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
class My_Example_List_Table extends WP_List_Table {

    function __construct(){
        global $status, $page;
            parent::__construct(array(
                'singular' => 'order',
                'plural' => 'orders',
            ));
        add_action( 'admin_head', array( &$this, 'admin_header' ) );        
    }
    
  function admin_header() {
    $page = ( isset($_GET['page'] ) ) ? esc_attr( $_GET['page'] ) : false;
    if( 'order-list' != $page )
    return;
    echo '<style type="text/css">';
    echo '.wp-list-table .column-id { width: 5%; }';
    echo '.wp-list-table .column-booktitle { width: 40%; }';
    echo '.wp-list-table .column-author { width: 35%; }';
    echo '.wp-list-table .column-isbn { width: 20%;}';
    echo '</style>';
  }
  
  function no_items() {
    _e( 'No Order found.' );
  }
  
      function column_default($item, $column_name)
    {
        return $item[$column_name];
    }
  
function get_sortable_columns() {
  $sortable_columns = array(
    //'sNo'  => array('sNo',false),
    //'course_id' => array('course_id',false),
  );
  return $sortable_columns;
}

function get_columns(){
        $columns = array(
            'cb'        => '<input type="checkbox" />',
            'course_name' => __( 'Course Name', 'mylisttable' ),
            'course_id'    => __( 'Course Id', 'mylisttable' ),
            'name'    => __( 'User Name', 'mylisttable' ),
            'booking_date'    => __( 'order date', 'mylisttable' )
        );
         return $columns;
    }
    
function usort_reorder( $a, $b ) {
  // If no sort, default to title
  $orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'course_id';
  // If no order, default to asc
  $order = ( ! empty($_GET['order'] ) ) ? $_GET['order'] : 'asc';
  // Determine sort order
  $result = strcmp( $a[$orderby], $b[$orderby] );
  // Send final sort direction to usort
  return ( $order === 'asc' ) ? $result : -$result;
}


function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="book[]" value="%s" />', $item['course_id']
        );    
    }
    
    function prepare_items()
    {
        include __DIR__."/prepare_items.php";
    }
    
} //class


function add_options() {
  global $myListTable;
  $option = 'per_page';
  $args = array(
         'label' => 'user Id',
         'default' => 10,
         'option' => 'cashier_per_page'
         );
  add_screen_option( $option, $args );
  $myListTable = new My_Example_List_Table();
  
}

function my_render_list_page(){
  global $myListTable;
  $myListTable = new My_Example_List_Table();
  echo '</pre><div class="wrap"><h2>Order List</h2>';
  
  $myListTable->prepare_items(); 
?>
  <form method="post">
    <input type="hidden" name="page" value="ttest_list_table">
    <?php
    //$myListTable->search_box( 'search', 'search_id' );
  $myListTable->display(); 
  echo '</form></div>'; 

}