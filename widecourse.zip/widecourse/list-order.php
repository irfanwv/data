<?php






add_filter( 'manage_edit-widecourse_columns', 'my_order_columns' );

function my_order_columns( $columns ) {
    $columns['widecourse-date'] = 'Start Date';
    $columns['widecourse-duration'] = 'Duration';
    $columns['widecourse-fee'] = 'Fees';
    $columns['widecourse-seat'] = 'Seat';
    $columns['widecourse-date-close'] = 'Close Date';
    unset( $columns['comments'] );
    return $columns;
}

	
 add_action( 'manage_posts_custom_column', 'populate_order_columns' );

function populate_order_columns( $column ) {
    if ( 'widecourse-date' == $column ) {
		$widecourse_date = esc_html( get_post_meta( get_the_ID(), 'widecourse_date', true ) );
        
        echo $widecourse_date;
    }
    elseif ( 'widecourse-fee' == $column ) {
        $widecourse_fee = esc_html( get_post_meta( get_the_ID(), 'widecourse_fee', true ) );
        echo $widecourse_fee;
    }
    elseif ( 'widecourse-duration' == $column ) {
        $widecourse_duration = esc_html( get_post_meta( get_the_ID(), 'widecourse_duration', true ) );
        echo $widecourse_duration;
    }
    elseif ( 'widecourse-seat' == $column ) {
        $widecourse_duration = esc_html( get_post_meta( get_the_ID(), 'widecourse_seat', true ) );
        echo $widecourse_duration;
    }
    elseif ( 'widecourse-date-close' == $column ) {
        $widecourse_duration = esc_html( get_post_meta( get_the_ID(), 'widecourse_date_close', true ) );
        echo $widecourse_duration;
    }
} 







?>