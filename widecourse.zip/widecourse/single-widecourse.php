<?php
get_header(); 
   $post_id = get_the_ID();
   $widecourse_date = get_post_meta($post_id, "widecourse_date", true);
   $target = get_post_meta($post_id, "widecourse_target", true);
  $duration = get_post_meta($post_id, "widecourse_duration", true);
  $fee = get_post_meta($post_id, "widecourse_fee", true);
  $fee_ini = get_post_meta($post_id, "widecourse_fee_ini", true);
  $widecourse_seat = get_post_meta($post_id, "widecourse_seat", true);
  $widecourse_date_close = get_post_meta($post_id, "widecourse_date_close", true);
  global $wpdb;
  
  //Take Order Now

        if(  check_availablity($post_id) > 0 )
        {
            $exp1 = strtotime($widecourse_date_close);
            if( strtotime(date('d-m-Y')) <= strtotime($widecourse_date_close) )
            {
                
              
              $course_id =  $_POST['course_id'];
              $user_id = $_POST['user_id'];
              $booking_date =  date('Y-m-d h:i:s');
              
             // $table_oreder_list = $wpdb->prefix . 'course_book';
             //// $sql = "INSERT INTO ".$table_oreder_list."(user_id, course_id, booking_date) VALUES ('$user_id', '$course_id', '$booking_date')";
             //// $query = $wpdb->query($sql);
             // if($query)
             // {
             //     $error = 'Seat Book Successfully';
             //      email ($post_id, $user_id); 
             // }              
            } else
            {
                $error = 'Sorry, Time Limit Exist';
            }

        } else
        { ?>
                  <script>
           function disableBtn() {
               document.getElementById("myBtn").disabled = true;
           }
           window.onload = disableBtn;
           </script>
            
<?php            //$error = 'Sorry, Seat Not Available';
        }
  
  
    
  ?>
<style>
    .courselink { color: #00a1e4; text-decoration: underline; }
    a.courselink:hover { color: #00a1e4; text-decoration: none;}
    a.courselink:visited { color: #00a1e4; text-decoration: underline; }
    #no_refunds_error { display: none; }
    #jp-relatedposts { display: none !important; }
    #content { width: 80% ; margin: 0 !important; float: left; }
</style>
 <script>
      
      function validateForm()
	{
            if(!document.forms["order"]["i_accept"].checked)
                  {
                     // alert("Date & Time must be filled out");
                      jQuery("#no_refunds_error").show();
                      return false;
                  }
	}

 </script>
<div id="primary">
    <div id="content" role="main">
     <?php $mypost = array(  'p' => $post_id, 'post_type' => 'widecourse',);
      $loop = new WP_Query( $mypost );
      //$post = get_post( $post_id );
      ?>
      <!-- Cycle through all posts -->
      <?php while ( $loop->have_posts() ) : $loop->the_post();?>
          <article id="post-<?php echo $post_id; ?>" <?php post_class(); ?>>
          
              <header class="entry-header">
                <?php if($error) { echo $error; } ?>
                <!-- Display featured image in top-aligned floating div -->
                 <div style="margin: 10px;">
                    <?php the_post_thumbnail( array( 100, 100 ) ); ?>
                    <?php //echo get_the_post_thumbnail( $post_id,  array( 100, 100 ) ); ?>
                 </div>
                 <!-- Display Title and Author Name -->
                 <strong>Title: </strong><?php  the_title(); //echo $post->post_title; ?>
                 <br />
                 <strong>Course Date: </strong><?php echo $widecourse_date; ?>
                 <br>
                  <strong>Course Duration: </strong><?php echo $duration; ?>
                 <br>
                  <strong>Course Fees: </strong><?php echo $fee; ?>
                 <br>
                  <strong>Course Seat: </strong><?php echo check_availablity($post_id).' / '.$widecourse_seat; ?>
                 <br />
                  <strong>Course Category: </strong><?php the_terms( $post_id, 'course-categories' ,  ' ' ); ?>
                 <br />
              </header>
              <!-- Display movie review contents -->
              <div class="entry-content">
                 <strong>Course Description: </strong>
                   <?php the_content($post_id); ?>
                   <?php  if(is_user_logged_in ())  { ?>
                    <form id="order" name="order" onsubmit="return validateForm()" action="<?php //echo $config->getItem('plugin_form_handler_url'); ?>http://www.risingfuture.com/wp-content/plugins/paypal-express-checkout/checkout/paypal_ec_mark.php" method="post">
                  
                    <input type="hidden" name="course_id" value="<?php echo $post_id; ?>">
                    <input type="hidden" name="user_id" value="<?php echo get_current_user_id(); ?>">
                    Reservation Fees: $<?php echo $fee_ini; ?> <input type="radio" name="AMT" value="<?php echo $fee_ini; ?>">&nbsp;&nbsp;&nbsp; Registration Fees: $<?php echo $fee; ?> <input type="radio" name="AMT" value="<?php echo $fee; ?>">
                 </br>
                 <div id="no_refunds_error" style="color:#FF0000;font-weight:bold;">You must accept that there are no refunds once you register before continuing.</div>
                 <input type="checkbox" name="i_accept" id="accept_no_refunds" value="on">
                  <span id="no_refunds_text">I accept there are no refunds once I register for this course.</span>
                 </br></br>
                    
                    <input name="CURRENCYCODE" value="USD" type="hidden">
                    <input name="func" value="start" type="hidden">
                  <?php  if(  check_availablity($post_id) > 0 ) { ?>
                        <input type="submit" name="submit" value="Register Now!" >
                  <?php } else { ?>
                        <button id="myBtn" >Register Now!</button> </br>
                        <p>Sorry, Seat Not Available</p>
                 <?php } ?>
                  </form>
                  
                  <?php } else {   ?>
                  <div style="padding: 5px; background-color: #F3F3F3;">
                        Please <a href="http://www.risingfuture.com/login-2/" class="courselink">Login</a> to Register For The Course.
                  </div>
                  <?php }    ?>
              </div>
              
         </article>
   <?php endwhile;  ?>
   </div>
   <div style="padding-top: 25px;"><button onclick="location.href = 'http://www.risingfuture.com/login-2/';" id="myButton" class="float-left submit-button" >Login</button></div> 
</div>
<?php wp_reset_query(); ?>
<?php get_footer(); ?>