<?php
/*
Plugin Name: Widecourse
Plugin URI: http://www.widetheme.com/
Description: Declares a plugin that will create a custom post type displaying widecourses offered by an institution.
Version: 1.0
Author: Wide theme
License: 
*/



add_action( 'plugins_loaded', 'wide_pluginActivate' );
register_activation_hook(__FILE__,'wide_pluginActivate');
function wide_pluginActivate()
    {
        
        global $wpdb;
	
	$table_oreder_list = $wpdb->prefix . 'course_book';
	$sql = "CREATE TABLE " . $table_oreder_list . " (
	      sNo bigint(20) NOT NULL AUTO_INCREMENT,
	      user_id bigint(20) unsigned NOT NULL,
	      course_id bigint(20) NOT NULL,
	      booking_date varchar(20) NOT NULL,
	      PRIMARY KEY (sNo)
	      
	    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
	   
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
	
    }
add_action( 'init', 'create_widecourse' );

function create_widecourse() {
    register_post_type( 'widecourse',
        array(
            'labels' => array(
                'name' => 'WideCourses',
                'singular_name' => 'Course',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Course',
                'edit' => 'Edit',
                'edit_item' => 'Edit Course',
                'new_item' => 'New Course',
                'view' => 'View',
                'view_item' => 'View Course',
                'search_items' => 'Search Courses',
                'not_found' => 'No Courses found',
                'not_found_in_trash' => 'No Courses found in Trash',
                'parent' => 'Parent Course'
            ),
            'public' => true,
	    'show_ui' => true,
            'show_in_menu' => true,
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'menu_icon' => 'dashicons-welcome-learn-more',
            'supports' => array( 'title', 'editor', 'thumbnail' ),
            'taxonomies' => array( 'course-categories' ),
            'has_archive' => true
        )
    );
}

add_action( 'init', 'create_my_taxonomies', 0 );

function create_my_taxonomies() {
    register_taxonomy(
        'course-categories',
        'course',
        array(
            'labels' => array(
                'name' => 'Course Category',
                'add_new_item' => 'Add New Course Category',
                'new_item_name' => "New Course Category"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'hierarchical' => true
        )
    );
}

//remove_role( 'student' );
add_action( 'init', 'create_student_role' );
function create_student_role()
    {
        add_role(
            'student',
            __( 'Student' ),
            array(
                'read'         => true,  // true allows this capability
                'edit_posts'   => true,
                'delete_posts' => false, // Use false to explicitly deny
            )
        );
    }

    
include('order-list.php');

add_action( 'admin_menu', 'my_plugin_menu' );

function my_plugin_menu() {
	 add_menu_page(
        __( 'WideCourses', 'textdomain' ),
        __( 'Wide Courses Orders', 'textdomain' ),
        'manage_options',
        'order-list',
        'my_render_list_page',
        'dashicons-list-view'
    );
  //add_submenu_page('order-list', 'Help', 'Help', 0, 'wide_help',  'wide_help');
 // add_options_page( 'Wide Courses Orders', 'My Plugin', 'manage_options', 'order-list', 'my_render_list_page' );
}    
    
//Create Course
    
 include('create-course.php');
 
 //Include template
add_filter( 'template_include', 'include_template_function', 1 );

function include_template_function( $template_path ) {
    if ( get_post_type() == 'widecourse' ) {
        if ( is_single() ) {
            // checks if the file exists in the theme first,
            // otherwise serve the file from the plugin
            if ( $theme_file = locate_template( array ( 'single-widecourse.php' ) ) ) {
                $template_path = $theme_file;
            } else {
                $template_path = plugin_dir_path( __FILE__ ) . '/single-widecourse.php';
            }
			
        }
		 elseif ( is_archive() ) {
            if ( $theme_file = locate_template( array ( 'archive-widecourse.php' ) ) ) {
                $template_path = $theme_file;
            } else { $template_path = plugin_dir_path( __FILE__ ) . '/archive-widecourse.php';
            }
        }
	
    }
    return $template_path;
}

//check seat availablity

function check_availablity($post_id)
{
    global $wpdb;
    $widecourse_seat = get_post_meta($post_id, "widecourse_seat", true);
    $sql = "SELECT * FROM ".$wpdb->prefix."course_book WHERE course_id=".$post_id;
    $wpdb->get_results( $sql );
    return  $widecourse_seat-$wpdb->num_rows;
    
}

function wide_help()
{
echo '
  <h2>Use Shortcodes</h2>
  
  <h4>Registration : </h4> 
  <p>
    [wide-registration] 
  </p>
  <h4>Login : </h4> 
  <p>
    [wide-login] 
  </p>
  ';
}

//Mail alert to user
function email ($post_id, $user_id)
{
    $post = get_post( $post_id );
    
	$subject="You have enrolled in ".$post->post_title;
	$body ="<div style=\"margin-left: 15%; margin-right: 20%; padding: 15px 0 15px 0; width: auto; min-width: 270px;\">";
       // $body .='<img src="'.myhost.'100x100.png" >';
	
	$body .="<p>You are Enrolled Successfully.</p>";
	
	
        $body .='<table width="100%" border="0" cellspacing="3" cellpadding="3" style="background:#fff; font-size:13px;
	    font-family:Verdana, Geneva, sans-serif;">
	    <tr style="background:#00476b; color:#fff;">
	    <td height="37" colspan="2" style="padding-left:20px; font-size: 15px;" align="center">Course Details</td>
	    </tr>';
	$body .="<tr style=\"background:#E7E7E7;\"><td width=\"50%\" height=\"40\" style=\"padding-left:20px;\">Course Name :</td><td width=\"50%\" style=\"padding-left:20px;\">".$post->post_title."</td></tr>";
	$body .="<tr style=\"background:#E7E7E7;\"><td width=\"50%\" height=\"40\" style=\"padding-left:20px;\">Course Duration :</td><td width=\"50%\" style=\"padding-left:20px;\">".get_post_meta($post_id, "widecourse_duration", true)."</td></tr>";
	$body .="<tr style=\"background:#E7E7E7;\"><td width=\"50%\" height=\"40\" style=\"padding-left:20px;\">Course Start Date :</td><td width=\"50%\" style=\"padding-left:20px;\">".get_post_meta($post_id, "widecourse_date", true)."</td></tr>";
        $body .="<tr style=\"background:#E7E7E7;\"><td width=\"50%\" height=\"40\" style=\"padding-left:20px;\">Course Fees :</td><td width=\"50%\" style=\"padding-left:20px;\">".get_post_meta($post_id, "widecourse_fee", true)."</td></tr>";
        $body .="<tr style=\"background:#E7E7E7;\"><td width=\"50%\" height=\"40\" style=\"padding-left:20px;\">Class Frequency :</td><td width=\"50%\" style=\"padding-left:20px;\">".get_post_meta($post_id, "widecourse_frequency", true)."</td></tr>";
	//$body .="<tr style=\"background:#E7E7E7;\"><td width=\"50%\" height=\"40\" style=\"padding-left:20px;\"></td><td width=\"50%\" align=\"center\"></td></tr>";
	 
	$body .="</table>";
	$body .="<div style=\"width: 100%;\">";
	$body .= "<p style=\"text-align: justify;\">NOTE: Please do not reply to this e-mail.</p>";
	$body .="<p></p>";
	$body .="<p>Thanks & Regards</p>";
	$body .="<p>Rising Future Team,<br>Email: <a href=\"mailto:contact@risingfuture.com\">contact@risingfuture.com</a></p></div>";
	
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    //$headers .= 'From: <info@flightplan.com>' . "\r\n";
    
    $user_info = get_userdata($user_id);
    //$multiple_recipients = array($user_email, $user_info->user_email);
    //echo $body.$user_info->user_email;
    $rslt = wp_mail( $user_info->user_email, $subject, $body,$headers );
 
    return $rslt;
}

//Registration
add_action( 'init', 'wpr_add_shortcodes' );
function wpr_add_shortcodes() {
add_shortcode( 'wide-registration', 'render_register_form' );
}
 function render_register_form( ) {
    if(isset($_POST['submit']))
    {
	if ( get_user_by('email', $_POST['email'] ) )
	{
	  echo $response    = "Username already exists.";
	} 
	else
	{
	      $usrId = wp_create_user( $_POST['username'],  $_POST['password'],  $_POST['email'] );
	      update_user_meta( $usrId, 'first_name', $_POST['first_name']);
	      update_user_meta( $usrId, 'last_name', $_POST['last_name']);
	     
	     echo $response    = "You Registration Successfully";
	}
	
    }
    
 include('register_form.php');

 }

//Login Form
//Registration
add_action( 'init', 'wpl_add_shortcodes' );
function wpl_add_shortcodes() {
add_shortcode( 'wide-login', 'render_login_form' );
}
 function render_login_form( ) {
    if(isset($_POST['submit']))
    {    
	$user_email = $_POST['email'];
	$user_pass = $_POST['password'];
	
        $user = get_user_by( 'login', $user_email );
	
        if(!$user->ID)
        {
            $user = get_user_by_email(  $user_email );
        }
            
	 $new_user_id = $user->ID;
	
	if(wp_check_password($user_pass, $user->user_pass, $user->ID))
	{		
	    wp_setcookie($user_email, $user_pass, true);
	    wp_set_current_user($new_user_id, $user_email);
	    do_action('wp_login', $user_email);
	     
	    // exit;
	    //echo 'helo';exit;
	}
    }
if ( !is_user_logged_in() )
{
    include('login_form.php');
    wp_login_form();
} else
{
    
}
 }
 
 
 add_action( 'init', 'blockusers_init' );

function blockusers_init() {
    if ( is_admin() && ! current_user_can( 'administrator' ) && 
       ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
        wp_redirect( home_url() );
        exit;
    }
}


//function wpse_11244_restrict_admin() {
//    if ( ! current_user_can( 'manage_options' ) ) {
//	wp_redirect( home_url() ); exit;
//        wp_die( __('You are not allowed to access this part of the site') );
//    }
//}
//add_action( 'admin_init', 'wpse_11244_restrict_admin', 1 );

?>