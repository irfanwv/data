<?php

   require_once("paypal_functions.php");
  
   //Call to SetExpressCheckout using the shopping parameters collected from the shopping form on index.php and few from config.php 

   $returnURL = RETURN_URL;
   $cancelURL = CANCEL_URL; 
   
 
	$_SESSION['post_value'] = $_POST;
	
	//Assign the Return and Cancel to the Session object for ExpressCheckout Mark
	$returnURL = RETURN_URL_MARK;
	$_SESSION['post_value']['RETURN_URL'] = $returnURL;
	$_SESSION['post_value']['CANCEL_URL'] = $cancelURL;
	$_SESSION['post_value']['PAYMENTREQUEST_0_AMT'] = 150;
	$_SESSION['EXPRESS_MARK'] = 'ECMark';
   include('header.php');
?>
   <div class="span4">
   </div>
   <div class="span5">
            <!--Form containing item parameters and seller credentials needed for SetExpressCheckout Call-->
            <form class="form" action="paypal_ec_mark.php" method="POST">
               <div class="row-fluid">
                  <div class="span6 inner-span">
                        <p class="lead">Shipping Address111</p>
                        <table>
                        <input type="hidden" name="PAYMENTREQUEST_0_AMT" value="150">
                        <tr><td width="30%">First Name</td><td>
			<input type="text" name="L_PAYMENTREQUEST_FIRSTNAME" value="Alegra"></input></td></tr>
                        <tr><td>Last Name:</td><td>
			<input type="text" name="L_PAYMENTREQUEST_LASTNAME" value="Valava"></input></td></tr>
                        <tr><td>Address</td><td><input type="text" name="PAYMENTREQUEST_0_SHIPTOSTREET" value="55 East 52nd Street"></input></td></tr>
                        <tr><td>Address 1</td><td><input type="text" name="PAYMENTREQUEST_0_SHIPTOSTREET2" value="21st Floor"></input></td></tr>
                        <tr><td>City:</td><td><input type="text" name="PAYMENTREQUEST_0_SHIPTOCITY" value="New York" ></input></td></tr>
                        <tr><td>State:</td><td><input type="text" name="PAYMENTREQUEST_0_SHIPTOSTATE" value="NY" ></input></td></tr>
                        <tr><td>Postal Code:</td><td><input type="text" name="PAYMENTREQUEST_0_SHIPTOZIP" value="10022" ></input></td></tr>
                        <tr><td>Country</td><td></td>
						</tr>
                        
                       

                        </table>
                        <input type="submit" id="placeOrderBtn" class="btn btn-primary btn-large" name="PlaceOrder" value="Place Order" />
                  </div>
               </div>
            </form>
   </div>
   <div class="span3">
   </div>
    <script src="//www.paypalobjects.com/api/checkout.js" async></script>
      <script type="text/javascript">
      window.paypalCheckoutReady = function () {
          paypal.checkout.setup('<?php echo($merchantID); ?>', {
              button: 'placeOrderBtn',
              environment: '<?php echo($env); ?>',
              condition: function () {
                      return document.getElementById('paypal_payment_option').checked === true;
                  }
          });
      };
      </script>
   <?php
   
   
?>
