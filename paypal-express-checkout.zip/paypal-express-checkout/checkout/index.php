<!DOCTYPE HTML>
<?php include('header.php');
      include('paypal_config.php'); ?>

<?php include('footer.php') ?>
