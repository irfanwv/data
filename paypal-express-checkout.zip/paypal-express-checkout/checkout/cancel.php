
<?php 

require_once("paypal_functions.php");
        //header("Location: ".get_permalink(get_option('paypal_cancel_page')));
	echo '<script>location.href="'.get_permalink(get_option('paypal_cancel_page')).'";</script>';
	exit;
?>