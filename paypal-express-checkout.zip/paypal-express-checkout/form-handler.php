<?php
session_start();

/**
 * Form posting handler
 */
require '../../../wp-load.php';
require ABSPATH.'wp-content/plugins/paypal-express-checkout/classes/paypalapi.php';

if ( isset($_GET['func']) && $_GET['func'] == 'confirm' && isset($_GET['token']) && isset($_GET['PayerID']) ) {
 // HCCoder_PayPalAPI::ConfirmExpressCheckout();
  
  if ( isset( $_SESSION['RETURN_URL'] ) ) {
    $url = $_SESSION['RETURN_URL'];
    unset($_SESSION['RETURN_URL']);
    $course_id =  $_SESSION['course_id'];
    $user_id = $_SESSION['user_id'];
    $booking_date =  date('Y-m-d h:i:s');
    $_SESSION['payer_id'] =	$_GET['PayerID'];
    if (isset($_REQUEST['token']))
    {
      $token = $_REQUEST['token'];
      $_SESSION['TOKEN'] = $token;
    }
    global $wpdb;
    //Insert record into course order
    $table_oreder_list = $wpdb->prefix . 'course_book';
    $sql = "INSERT INTO ".$table_oreder_list."(user_id, course_id, booking_date) VALUES ('$user_id', '$course_id', '$booking_date')";
    $query = $wpdb->query($sql);
    
    //insert record into paypal payment history
  $userdatea = get_userdata( $_SESSION['user_id'] ); 
 $insert_data = array('token' => $_SESSION['TOKEN'],
                      'amount' => $_SESSION['Payment_Amount'],
                      'currency' => $_SESSION['currencyCodeType'],
                      'status' => 'pending',
                      'firstname' => $user_last = get_user_meta( $_SESSION['user_id'], 'first_name', true ),
                      'lastname' => $user_last = get_user_meta( $_SESSION['user_id'], 'last_name', true ),
                      'email' => $userdatea->user_email,
                      'description' => 'Course-'.$_SESSION['payer_id'],
                      'summary' => 'payemnt',
                      'created' => time());
      $insert_format = array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d');
      $wpdb->insert('hccoder_paypal', $insert_data, $insert_format);
      
     // check payment status
            $resultArr = array( 'PAYERID' => $_SESSION['payer_id'],
      		    'TOKEN' => $_SESSION['TOKEN'],
      		    'AMT' => $_SESSION['Payment_Amount']
      		   );
              HCCoder_PayPalAPI::DoExpressCheckout($resultArr);
	
        header('Location: http://www.risingfuture.com/thank-you-2/');
	echo '<script>location.href="http://www.risingfuture.com/thank-you-2/";</script>';
    exit;
  }
  
  if ( is_numeric(get_option('paypal_success_page')) && get_option('paypal_success_page') > 0 )
    header('Location: '.get_permalink(get_option('paypal_success_page')));
  else
    header('Location: '.home_url());
  exit;
}
if ( isset($_GET['func']) && $_GET['func'] == 'failed' && isset($_GET['token'])  )
{
        header("Location: ".get_permalink(get_option('paypal_cancel_page')));
	echo '<script>location.href="'.get_permalink(get_option('paypal_cancel_page')).'";</script>';
    
}
//if ( ! count($_POST) )
//  trigger_error('Payment error code: #00001', E_USER_ERROR);
//
//$allowed_func = array('start');
//if ( count($_POST) && (! isset($_POST['func']) || ! in_array($_POST['func'], $allowed_func)) )
//  trigger_error('Payment error code: #00002', E_USER_ERROR);
//  
//if ( count($_POST) && (! isset($_POST['AMT']) || ! is_numeric($_POST['AMT']) || $_POST['AMT'] < 0) )
//  trigger_error('Payment error code: #00003', E_USER_ERROR);
//  
switch ( $_POST['func'] ) {
  case 'start':
    $fee = get_post_meta($_POST['course_id'], "widecourse_fee", true);
    if($fee == $_POST['AMT'])
    {
      $amnt = $_POST['AMT'];
      $amnt = $amnt+$amnt*0.03;
    } else
    {
      $amnt = $_POST['AMT'];
    }
    
    $_SESSION['RETURN_URL'] = site_url().'/wp-content/plugins/paypal-express-checkout/form-handler.php';
    $_SESSION['course_id'] = $_POST['course_id'];
    $_SESSION['user_id'] = $_POST['user_id'];
    	$_SESSION['post_value']['RETURN_URL'] = site_url().'/wp-content/plugins/paypal-express-checkout/form-handler.php';
	$_SESSION['post_value']['CANCEL_URL'] = site_url().'/wp-content/plugins/paypal-express-checkout/form-handler.php';
	$_SESSION['post_value']['PAYMENTREQUEST_0_AMT'] = $amnt;
	$_SESSION['post_value']['currencyCodeType'] = 'USD';
    $_SESSION['EXPRESS_MARK'] = 'ECMark';
    $_SESSION['Payment_Amount'] = $amnt;
    $_SESSION['currencyCodeType'] = 'USD';
    
   //  print_r($_SESSION); exit;
    HCCoder_PayPalAPI::StartExpressCheckout();
    break;
}