<?php
session_start();

/**
 * PayPal API
 */
if ( ! class_exists('HCCoder_PayPalAPI') ) {

  class HCCoder_PayPalAPI {
  
    /**
     * Start express checkout
     */
    function StartExpressCheckout() {
      
      $config = HCCoder_PayPalConfig::getInstance();
      
      if ( get_option('paypal_environment') != 'sandbox' && get_option('paypal_environment') != 'live' )
        trigger_error('Environment does not defined! Please define it at the plugin configuration page!', E_USER_ERROR);
      
      if ( get_option('paypal_cancel_page') === FALSE || ! is_numeric(get_option('paypal_cancel_page')) )
        trigger_error('Cancel page not defined! Please define it at the plugin configuration page!', E_USER_ERROR);
      
      if ( get_option('paypal_success_page') === FALSE || ! is_numeric(get_option('paypal_success_page')) )
        trigger_error('Success page not defined! Please define it at the plugin configuration page!', E_USER_ERROR);
      $fee = get_post_meta($_POST['course_id'], "widecourse_fee", true);
        if($fee == $_POST['AMT'])
        {
          $amnt = $_POST['AMT'];
          $amnt = $amnt+$amnt*0.03;
        } else
        {
          $amnt = $_POST['AMT'];
        }
      // FIELDS
      $fields = array(
              'USER' => urlencode(get_option('paypal_api_username')),
              'PWD' => urlencode(get_option('paypal_api_password')),
              'SIGNATURE' => urlencode(get_option('paypal_api_signature')),
              'VERSION' => urlencode('72.0'),
              'PAYMENTREQUEST_0_PAYMENTACTION' => urlencode('Sale'),
              'PAYMENTREQUEST_0_AMT0' => urlencode($amnt),
              'PAYMENTREQUEST_0_AMT' => urlencode($amnt),
              'PAYMENTREQUEST_0_ITEMAMT' => urlencode($amnt),
              'ITEMAMT' => urlencode($amnt),
              'PAYMENTREQUEST_0_CURRENCYCODE' => urlencode($_POST['CURRENCYCODE']),
              'RETURNURL' => urlencode($config->getItem('plugin_form_handler_url').'?func=confirm'),
              'CANCELURL' => urlencode($config->getItem('plugin_form_handler_url').'?func=failed'),
              'METHOD' => urlencode('SetExpressCheckout')
          );
      
      if ( isset($_POST['PAYMENTREQUEST_0_DESC']) )
        $fields['PAYMENTREQUEST_0_DESC'] = $_POST['PAYMENTREQUEST_0_DESC'];
      
      if ( isset($_POST['RETURN_URL']) )
        $_SESSION['RETURN_URL'] = $_POST['RETURN_URL'];
      
      if ( isset($_POST['CANCEL_URL']) )
        $fields['CANCELURL'] = $_POST['CANCEL_URL'];
      
      if ( isset($_POST['PAYMENTREQUEST_0_QTY']) ) {
        $fields['PAYMENTREQUEST_0_QTY0'] = $_POST['PAYMENTREQUEST_0_QTY'];
        $fields['PAYMENTREQUEST_0_AMT'] = $fields['PAYMENTREQUEST_0_AMT'] * $_POST['PAYMENTREQUEST_0_QTY'];
        $fields['PAYMENTREQUEST_0_ITEMAMT'] = $fields['PAYMENTREQUEST_0_ITEMAMT'] * $_POST['PAYMENTREQUEST_0_QTY'];
        $fields['ITEMAMT'] = $fields['ITEMAMT'] * $_POST['PAYMENTREQUEST_0_QTY'];
        
      }
      
      
      if ( isset($_POST['TAXAMT']) ) {
        $fields['PAYMENTREQUEST_0_TAXAMT'] = $_POST['TAXAMT'];
        $fields['PAYMENTREQUEST_0_AMT'] += $_POST['TAXAMT'];
      }
      
            
      if ( isset($_POST['HANDLINGAMT']) ) {
        $fields['PAYMENTREQUEST_0_HANDLINGAMT'] = $_POST['HANDLINGAMT'];
        $fields['PAYMENTREQUEST_0_AMT'] += $_POST['HANDLINGAMT'];
      }
            
      if ( isset($_POST['SHIPPINGAMT']) ) {
        $fields['PAYMENTREQUEST_0_SHIPPINGAMT'] = $_POST['SHIPPINGAMT'];
        $fields['PAYMENTREQUEST_0_AMT'] += $_POST['SHIPPINGAMT'];
      }
      
      $fields_string = '';

      foreach ( $fields as $key => $value ) 
        $fields_string .= $key.'='.$value.'&';
        
      $fields_string =  rtrim($fields_string,'&');
      // $fields_string="METHOD=SetExpressCheckout&VERSION=109.0&USER=gurpreetchawla_api1.msn.com&PWD=5XKDY7SFLUC4CTJ8&SIGNATURE=AwtKPLj6qju7QJB0y2vFyxlyUGwHAYLKEDAnCorL8p-qJnh.JnvY5Q6-&PAYMENTREQUEST_0_PAYMENTACTION=Sale&PAYMENTREQUEST_0_AMT0=1&PAYMENTREQUEST_0_AMT=1&PAYMENTREQUEST_0_ITEMAMT=1&ITEMAMT=1&PAYMENTREQUEST_0_CURRENCYCODE=USD&RETURNURL=http%3A%2F%2Flocalhost%3A8888%2Fwordpress%2Fwp-content%2Fplugins%2Fpaypal-express-checkout%2Fform-handler.php%3Ffunc%3Dconfirm&CANCELURL=http%3A%2F%2Flocalhost%3A8888%2Fwordpress%2Ffailed%2F&BUTTONSOURCE=PP-DemoPortal-EC-IC-php";
      //echo $fields_string;
        // print_r($_SESSION);  exit;
      // CURL
      $ch = curl_init();
      
      if ( get_option('paypal_environment') == 'sandbox' )
        curl_setopt($ch, CURLOPT_URL, 'https://api-3t.sandbox.paypal.com/nvp');
      elseif ( get_option('paypal_environment') == 'live' )
        curl_setopt($ch, CURLOPT_URL, 'https://api-3t.paypal.com/nvp');
      curl_setopt($ch, CURLOPT_VERBOSE, 1);
      curl_setopt($ch, CURLOPT_POST, count($fields));
      curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
		//turning off the server and peer verification(TrustManager Concept).
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_SSLVERSION ,CURL_SSLVERSION_TLSv1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);
		
      //execute post
       $result = curl_exec($ch);
     // print_r(curl_error($ch));
      //close connection
      curl_close($ch);
      
      
      
      
      
      
      
      parse_str($result, $result);
      
      if ( $result['ACK'] == 'Success' ) {
        
        if ( get_option('paypal_environment') == 'sandbox' )
        {
          header('Location: https://www.sandbox.paypal.com/webscr?cmd=_express-checkout&token='.$result['TOKEN']);
        }
        elseif ( get_option('paypal_environment') == 'live' )
        {     //echo $result['TOKEN'];
         header('Location: https://www.paypal.com/checkoutnow?token='.$result['TOKEN'].'&useraction=commit');
          //header('Location: https://www.paypal.com/webscr?cmd=_express-checkout&token='.$result['TOKEN']);
        exit;         
        }

        
      } else {
        print_r($result);
      }
      
    }

    
    	function StartExpressCheckout1()
	{
		 $config = HCCoder_PayPalConfig::getInstance();
      

      // FIELDS

              $API_UserName = get_option('paypal_api_username'); 
              $API_Password = get_option('paypal_api_password');
              $API_Signature = get_option('paypal_api_signature');
              $sBNCode = "PP-DemoPortal-EC-IC-php";
              $methodName='SetExpressCheckout';
              $version = '109.0';
		//setting the curl parameters.
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://api-3t.paypal.com/nvp');
		curl_setopt($ch, CURLOPT_VERBOSE, 1);

		//turning off the server and peer verification(TrustManager Concept).
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_SSLVERSION ,CURL_SSLVERSION_TLSv1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);
$nvpStr = "&PAYMENTREQUEST_0_AMT=1&RETURNURL=" . ($_SESSION['RETURN_URL']) . "&CANCELURL=" . ($_SESSION['CANCEL_URL']) . "&PAYMENTREQUEST_0_CURRENCYCODE=USD";
		//NVPRequest for submitting to server
		 $nvpreq="METHOD=" . urlencode($methodName) . "&VERSION=" . urlencode($version) . "&PWD=" . urlencode($API_Password) . "&USER=" . urlencode($API_UserName) . "&SIGNATURE=" . urlencode($API_Signature) . $nvpStr . "&BUTTONSOURCE=" . urlencode($sBNCode);
              // echo $nvpreq; exit;
		//setting the nvpreq as POST FIELD to curl
		curl_setopt($ch, CURLOPT_POSTFIELDS, $nvpreq);

		//getting response from server
     echo $result = curl_exec($ch); exit;
      
      //close connection
      curl_close($ch);
      
      
      
      
      
      
      
      parse_str($result, $result);
      
      if ( $result['ACK'] == 'Success' ) {
        
        if ( get_option('paypal_environment') == 'sandbox' )
          header('Location: https://www.sandbox.paypal.com/webscr?cmd=_express-checkout&token='.$result['TOKEN']);
        elseif ( get_option('paypal_environment') == 'live' )
          header('Location: https://www.paypal.com/webscr?cmd=_express-checkout&token='.$result['TOKEN']);
        exit;
        
      } else {
        print_r($result);
	}
    
        }
    
    /**
     * Validate payment
     */
        function ConfirmExpressCheckout() {
    
      $config = HCCoder_PayPalConfig::getInstance();
      $userdatea = get_userdata( $_SESSION['user_id'] );
      
      $insert_data = array('token' => $_SESSION['TOKEN'],
                           'amount' => $_SESSION['PaymentType'],
                           'currency' => $_SESSION['currencyCodeType'],
                           'status' => 'pending',
                           'firstname' => $user_last = get_user_meta( $_SESSION['user_id'], 'first_name', true ),
                           'lastname' => $user_last = get_user_meta( $_SESSION['user_id'], 'last_name', true ),
                           'email' => $userdatea->user_email,
                           'description' => 'Course Booke',
                           'summary' => '',
                           'created' => time());
      HCCoder_PayPalAPI::SavePayment($insert_data, 'pending');
      
      		//mandatory parameters in DoExpressCheckoutPayment call
                $resultArr = array( 'PAYERID' => $_SESSION['payer_id'],
                                    'TOKEN' => $_SESSION['TOKEN'],
                                    'AMT' => $_SESSION['Payment_Amount']
                                   );


        HCCoder_PayPalAPI::DoExpressCheckout($resultArr);
     
    }
    
    /**
     * Close transaction
     */
    function DoExpressCheckout($result) {
    
      $config = HCCoder_PayPalConfig::getInstance();
    
      // FIELDS
      $fields = array(
              'USER' => urlencode(get_option('paypal_api_username')),
              'PWD' => urlencode(get_option('paypal_api_password')),
              'SIGNATURE' => urlencode(get_option('paypal_api_signature')),
              'VERSION' => urlencode('109.0'),
              'PAYMENTREQUEST_0_PAYMENTACTION' => urlencode('Sale'),
              'PAYERID' => urlencode($result['PAYERID']),
              'TOKEN' => urlencode($result['TOKEN']),
              'PAYMENTREQUEST_0_AMT' => urlencode($result['AMT']),
              'METHOD' => urlencode('SetExpressCheckout')
          );
      
      $fields_string = '';
      foreach ( $fields as $key => $value)
        $fields_string .= $key.'='.$value.'&';
      rtrim($fields_string,'&');
      
      // CURL
      $ch = curl_init();
      
      if ( get_option('paypal_environment') == 'sandbox' )
        curl_setopt($ch, CURLOPT_URL, 'https://api-3t.sandbox.paypal.com/nvp');
      elseif ( get_option('paypal_environment') == 'live' )
        curl_setopt($ch, CURLOPT_URL, 'https://api-3t.paypal.com/nvp');
      
      curl_setopt($ch, CURLOPT_POST, count($fields));
      curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      
      //execute post
      $result = curl_exec($ch);
      //close connection
      curl_close($ch);
      
      parse_str($result, $result);
      
      if ( $result['ACK'] == 'Success' ) {
        HCCoder_PayPalAPI::UpdatePayment($result, 'success');
      } else {
        HCCoder_PayPalAPI::UpdatePayment($result, 'failed');
      }
    }
    
    /**
     * Save payment result into database
     */
    function SavePayment($result, $status) {
      global $wpdb;
      
      $insert_data = array('token' => $result['TOKEN'],
                           'amount' => $result['AMT'],
                           'currency' => $result['CURRENCYCODE'],
                           'status' => 'pending',
                           'firstname' => $result['FIRSTNAME'],
                           'lastname' => $result['LASTNAME'],
                           'email' => $result['EMAIL'],
                           'description' => $result['PAYMENTREQUEST_0_DESC'],
                           'summary' => serialize($result),
                           'created' => time());
      
      $insert_format = array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d');
      
      $wpdb->insert('hccoder_paypal', $insert_data, $insert_format);
    }
    
    /**
     * Update payment
     */
    function UpdatePayment($result, $status) {
      global $wpdb;
      
      $update_data = array('transaction_id' => $result['PAYMENTINFO_0_TRANSACTIONID'],
                           'status' => $status);
      
      $where = array('token' => $result['TOKEN']);
      
      $update_format = array('%s', '%s');
      
      $wpdb->update('hccoder_paypal', $update_data, $where, $update_format);
    }
    
  }
  
}