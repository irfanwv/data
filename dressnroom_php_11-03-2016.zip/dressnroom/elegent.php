<?php

//error_reporting(-1);
//ini_set('display_errors', 'On');
//ini_set('memory_limit', '-1');

$event=$_POST['event'];
$genderId=$_POST['genderId'];

$data=array();
$response=array();
$info = array();
/*
 *Make $arrayCategory array for all categories of a section
 *event 4 = elegant, 3 = after 5, 2 = casual, 1 = formal	
 */

	if($genderId == 1 && $event==4)
	{
		$arrayCategory = array(21,377);
	} else if($genderId == 1 && $event==3)
	{
		$arrayCategory = array(21,22);
	} else if($genderId == 1 && $event==2)
	{
		$arrayCategory = array(10, 5, 47, 13, 2, 52);
	} else if($genderId == 1 && $event==1)
	{
		$arrayCategory = array(11, 3, 51, 64, 394);
	} else if($genderId == 2 && $event==4)
	{
		$arrayCategory = array(378,387,383,385,389,391,392,393);
	}else if($genderId == 2 && $event==3)
	{
		$arrayCategory = array(74,396,397,398); 
	}else if($genderId == 2 && $event==2)
	{
		$arrayCategory = array(85, 91, 124,147,80);
	}else if($genderId == 2 && $event==1)
	{
		$arrayCategory = array(71, 79, 87, 100, 146);
	}    
 if($genderId != NULL && $event != NULL)
 { foreach($arrayCategory as $parentCategory)
    {	
	$qry ="SELECT * FROM `categoryinfo` WHERE `parentCategory`='".$parentCategory."' AND `genderId`='".$genderId."'";
	
	$get_res = mysqli_query($conn, $qry) or die (mysqli_error());
	
	$no_of_row=mysqli_num_rows($get_res);
	if($no_of_row > 0)
	{
		while ($row = mysqli_fetch_array($get_res, MYSQLI_ASSOC))
	    { 
		       $info['categoryId'] = $row['categoryId'];
		       $info['categoryName'] = $row['categoryName'];
		       $info['genderId'] = $row['genderId'];
		       $info['categoryPic'] = $row['categoryPic'];
		       $data[]=$info;
		
	    }
	    
		    
	} else
	{
		$qry ="SELECT * FROM `categoryinfo` WHERE `categoryId`='".$parentCategory."' AND `genderId`='".$genderId."'";
		
		$get_res = mysqli_query($conn, $qry) or die (mysqli_error());
	     while ($row = mysqli_fetch_array($get_res, MYSQLI_ASSOC))
	     {
	       $info['categoryId'] = $row['categoryId'];
	       $info['categoryName'] = $row['categoryName'];
	       $info['genderId'] = $row['genderId'];
	       $info['categoryPic'] = $row['categoryPic'];
	       $data[]=$info;
	     }
	    
		
	}
   }
		    $response["error"] = 0;
		    $response["success"] = 1;
		    $response['product']=$data; 
		    $response["message"] = "Category listing Successfully!";
	
  }
	else
	{
                    $response["error"] = 1;
		    $response["success"] = 0;
		    $response["message"] = "Insert Currect Data!";
                
        }
	
echo json_encode($response);



?>