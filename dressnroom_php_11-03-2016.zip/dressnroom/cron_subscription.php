<?php

/*
 *
 *This is Cronjob file, It is reset the current counter of every category in given time.
 */


require 'db_conf.php'; 
include 'simplepush.php'; //for iphone notification

/*** Start Favorite Products Notification ***/
      $qry = "SELECT us.*, rg.gcmId, rg.deviceType FROM `userSubscription` AS us INNER JOIN `registration` AS rg ON us.userId=rg.id WHERE rg.id=17";
      $resultIds = mysqli_query($conn, $qry);
      //$rows = mysqli_fetch_assoc($resultId);
      foreach ($resultIds as $gcmRow)
      {
        $subscriptionType = $gcmRow['subscriptionType'];
        $subscriptionDate = $gcmRow['subscriptionDate'];
        $datetime1 = new DateTime();
        if($subscriptionType == 'TYPE2')
	    {
	      $subscriptionDate;
              $exp1 = date('Y-m-d', strtotime('+30 day', strtotime($subscriptionDate)));
              $exp2 = date('Y-m-d', strtotime('-7 day', strtotime($exp1)));
              $datetime2 = new DateTime($exp1);
              $interval = $datetime1->diff($datetime2);
              $response['expriration_daysleft'] = $interval->d;
               if(date('Y-m-d')>=$exp2 && date('Y-m-d')<$exp1)
               {
                  $is_expired= TRUE;
               }
               else
               {
                  $is_expired= FALSE;
               }
	    }elseif($subscriptionType == 'TYPE3')
	    {
		
                  $exp1 = date('Y-m-d', strtotime('+365 day', strtotime($subscriptionDate)));
                  $exp2 = date('Y-m-d', strtotime('-7 day', strtotime($exp1)));
                  $datetime2 = new DateTime($exp1);
                  $interval = $datetime1->diff($datetime2);
                    if($interval->m)
                    {
                     $now = time(); // or your date as well
                     $your_date = strtotime($exp1);
                     $datediff =  $your_date-$now;
                     $response['expriration_daysleft'] = floor($datediff/(60*60*24));
                    } else
                    {
                      $response['expriration_daysleft'] = $interval->d; 
                    }
                    
               if(date('Y-m-d')>=$exp2 && date('Y-m-d')<$exp1)
               {
                  $is_expired= TRUE;
		  
               }                         
               else
               {
                    $is_expired= FALSE;   
               }
	    }
	
	
        $info['exprirationDate'] = $exp1;
        $info['subscriptionDate'] = $gcmRow['subscriptionDate'];
        $data[]=$info;
          $pushnoti = array();
          $pushnoti['type'] = 'subscriptionNotification';	//"Subscription will expire on ".$exp1;
          $pushnoti['body'] = array( 'message' => "Subscription will expire on ".$exp1, 'data'=> $data);	//$data;
         
      if($is_expired == TRUE)
      {      
        if($gcmRow['deviceType'] == 1)
        {   
          
          send_notification_iphone ($gcmRow['gcmId'], $pushnoti);
        } else
        {
          $pushnoti = array();
	  $pushnoti['type'] = 'subscriptionNotification';
          $pushnoti['body'] =  array( 'message' => "Subscription will expire on ".$exp1, 'data'=> $data);
	  echo json_encode($pushnoti);
          echo send_notification ($gcmRow['gcmId'], $pushnoti);
        }
      }
      
    }
unset($data);
unset($info);
unset($pushnoti);
exit;
/*** Start Favorite Products Notification ***/
                function sendmail($to, $data)
                {
                         $subject="Reduce Price of Your Favorite Products ON DressNroom";
			 $body ="<div style=\"margin-left: 15%; margin-right: 20%; padding: 15px 0 15px 0; width: auto; min-width: 290px;\">";
			 
			// $body .="<p>Please print or save a copy of this receipt for your records.</p>";
			 
			 
			$body .="<table border=\"1\" cellspacing=\"0\" cellpadding=\"5\" width=\"100%\">";
			$body .="<tr><td colspan=\"3\" align=\"center\" bgcolor=\"#2DB9C1\"><p style=\"font-weight: 600;\">Your Favorite Products Details</p></td></tr>";
                        foreach ($data as $key)
                        {
                         
			$body .="<tr><td rowspan=\"2\"><img width=\"50%\" src=".$key['productImage']."></td><td width=\"40%\">Product Title:</td><td>".$key['title']."</td></tr>";
			$body .="<tr><td>Sale Price  :</td><td>".$key['sale_price']."</td></tr>";
                        }
			$body .="</table>";
			 
			 
			 $body .="<div style=\"width: 100%;\">";
                         //$body .="<p style=\"text-align: justify;\">In compliance with income tax rules and to allow you to use this letter as a receipt for your gift for tax purposes, we are confirming that LuvIt! provided you with no goods or services in return for your gift.</p>";
			 $body .="<p></p>";
			
			 $body .="<p>Dressn'Room Team,<br>Email: <a href=\"mailto:info@dressnroom.com\">info@dressnroom.com</a></p></div>";
			 
			 $name="Dressn'Room App";
			 // Always set content-type when sending HTML email
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					// More headers
			$headers .= 'From: <thepurplevision.seo@gmail.com>' . "\r\n";
                        
                        $mailsend = mail($to,$subject,$body,$headers);
                      
                }


  
$userResult = mysqli_query($conn,"SELECT DISTINCT(id) FROM `productFavorite`");

foreach($userResult as $uid)
{
  
  $result = mysqli_query($conn, "SELECT P1.*, P2.productName, P2.productImage, P2.productPrice AS price, P2.productSaleprice AS salePrice FROM productFavorite AS P1 INNER JOIN productinfo AS P2 ON P1.productId = P2.productId WHERE P1.id = ".$uid['id']);
  
   while ($row = mysqli_fetch_assoc($result))
    {
            $p11 = $row['productPrice'];
            $p12= $row['productSaleprice'];
            $p21 = $row['price'];
            $p22 = $row['salePrice'];
           if($p11 > $p21 && $p12 > $p22)
           {    
                 $info['title'] = $row['productName'];
                 $info['productId'] = $row['productId'];
                 $info['original_price'] = $p21;
                 $info['sale_price'] = $p22;
                 $info['productImage'] = $row['productImage'];

              
           } elseif ($p11 > $p21)
           {
            
              
                 $info['title'] = $row['productName'];
                 $info['productId'] = $row['productId'];
                 $info['original_price'] = $p21;
                 $info['productImage'] = $row['productImage'];
           } elseif ($p12 > $p22)
           {
            
                 $info['title'] = $row['productName'];
                 $info['productId'] = $row['productId'];
                 $info['sale_price'] = $p22;
                 $info['productImage'] = $row['productImage'];

           }
           else
           {
            //echo 'fail';
           }
                 $info['type'] = 'favorite';
                 $data[]=$info;
    }
   
      $qry = "SELECT * FROM `registration` WHERE id =".$uid['id'];
      $resultId = mysqli_query($conn, $qry);
      $rows = mysqli_fetch_assoc($resultId);
      echo '<pre>';
      
      echo $rows['gcmId']."<br>";
      if(!empty($data) || $data!= "")
      {
                
          $pushnoti = array();
          $pushnoti['message'] = "You Have Notification from DressNRoom";
          $pushnoti['body'] = $data;
          echo json_encode($pushnoti);
        if($rows['deviceType'] == 1)
        {   
          send_notification_iphone ($rows['gcmId'], $data);
        } else
        {
          
          $pushnoti = array();
          $pushnoti['message'] = "You Have Notification from DressNRoom";
          $pushnoti['body'] = $data;
         echo send_notification ($rows['gcmId'], $pushnoti);
         
        }
         
        if($rows['email'] != "")
        { $rws='mohammad.irfan@widevision.co.in';
         $rws= $rows['email'];
          sendmail($rws, $data); 
        }
        
      }
      unset($data);
  }
  
  /*** Start Favorite Products Notification ***/
 ?>