<?php
$start = microtime(true);

ini_set('memory_limit', '-1');



$user_id=$_POST['user_id'];
$productId=$_POST['productId'];
$productPrice=$_POST['productPrice'];
$productSaleprice=$_POST['productSaleprice'];
$data=array();
   if(!empty($user_id) || $user_id!="")
   {
/*
 * Fetch User's Profile
 * 
 */
       if(!empty($productId) || $productId!="")
      {
	 $qry .= 'INSERT INTO `productFavorite`(`productId`, `productPrice`, `productSaleprice`, `id`)';
	 $qry .= 'VALUES ("'.$productId.'","'.$productPrice.'","'.$productSaleprice.'","'.$user_id.'");';
	 $results = mysqli_query($conn, $qry) or die (mysqli_error());
	 if(mysqli_insert_id($conn)!="")
	 {
	    $response["error"] = 0;
	    $response["success"] = 1;    
	    $response["message"] = "Product added in favorite succefully!";
	 }else
	 {
	    $response["error"] = 1;
	    $response["success"] = 0;    
	    $response["message"] = "Product Not added in favorite!";
	 }
      }else
      {
	 $qrry = "SELECT pf.*, pi.productName, pi.productImage, pi.productLink, pi.sourceId FROM `productFavorite` AS pf INNER JOIN `productinfo` AS pi ON pi.productId=pf.productId WHERE pf.id=".$user_id;
	 $result = mysqli_query($conn, $qrry) or die (mysqli_error());
	  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
	    {
	       $info['productId'] = $row['productId'];
	       $info['productName'] = $row['productName'];
	       $info['productImage'] = $row['productImage'];
	       
	       $info['productLink'] = $row['productLink'];
	       $info['productPrice'] = $row['productPrice'];
	       $info['productSaleprice'] = $row['productSaleprice'];
	       $sourceId = $row['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $data[]=$info;
	    }
	 $response["error"] = 0;
	 $response["success"] = 1;
	 $response["productlist"] = $data;
	 $response["message"] = "favorite products list!";
      }      
      
   }else
   {
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "User Not Valid!";
   }

      
echo json_encode($response);
exit;

?> 