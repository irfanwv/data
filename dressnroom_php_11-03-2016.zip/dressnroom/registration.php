<?php
  
$response = array();
$firstName=$_POST['firstName'];
$lastName=$_POST['lastName'];
$email=$_POST['email'];
$password= md5($_POST['password']);
$device_id=$_POST['device_id'];
$gcmId=$_POST['gcmId'];
$deviceType=$_POST['deviceType'];


//check emailid registeres

$qry = "SELECT * FROM `registration` WHERE `email`='$email'";
$check_email = mysqli_query($conn, $qry);


$count = mysqli_num_rows($check_email);

if($count < 1)
{

    $qry = "INSERT INTO `registration`(`firstName`, `lastName`, `email`, `password`, `device_id`, `create_date`, `login_status`, `gcmId`, `deviceType`)";
    $qry .= "VALUES ( '$firstName','$lastName','$email','$password','$device_id', '', '','$gcmId', '$deviceType' )";

    $data = mysqli_query($conn, $qry);
    $last_saved_id = mysqli_insert_id($conn);
     
    if($data!=false)
    {		//user_id
	$response["user_id"] = $last_saved_id;
	$response["error"] = 0;
	$response["success"] = 1;
	$response["message"] = "Registration Successfully Done";
    }		  
    else
     {
	 $response["error"] = 1;
	 $response["success"] = 0;
	 $response["message"] = "Registration Fail !";
     }  
}
else
{
    $response["error"] = 1;
    $response["success"] = 0;
    $response["message"] = "Email already registered !";
}
/*print response in json format*/
echo json_encode($response);
?>
