<?php /* Start GAP.com*/
	 
include 'db_conf.php';
date_default_timezone_set("UTC");
$handle = fopen('php://input','r');
$jsonInput = fgets($handle);
$decoded = json_decode($jsonInput,true);

    include_once("snoopy.class.php");
    include_once("htmlsql.class.php");
    $imgLink = array();
    $price = array();
    $del = array();
    $array1 = array();
    $i=0;
    $sourceId = 2;
    $qry11 = '';
    $qry12 = '';
    $productCatid = $_GET['categoryId'];
    $genderId = $_GET['genId'];
    $update = $_GET['update'];
    $user_id = $_GET['user_id'];
    $filter= $_GET['filter'];


    if($update=='yes'){
    
	/*
	 *If Need Update
	 **/
    
   
    $qry = "SELECT * FROM `categoryMapping` WHERE categoryId ='".$productCatid."' AND `sourceId` = '2'"; // sourceId [Bonton =1, Gap=4]
    $results = mysqli_query($conn, $qry);
    $dat = mysqli_fetch_assoc($results);
    $link = "http://www.gap.com/".$dat["categoryUrl"];
     
    /*
     *Make Gap Category URL From database
     *
     **/
    //echo $link; exit;
    if($dat["categoryUrl"] != "")
   {
    $wsql = new htmlsql();
    
    
    if (!$wsql->connect('url', $link)){
        print 'Error while connecting: ' . $wsql->error;
        exit;
    }
    
    
    if (!$wsql->query('SELECT * FROM * WHERE $class == "brand1 productCatItem"')){
        print "Query error: " . $wsql->error; 
        exit;
    }

    // show results:
    foreach($wsql->fetch_array() as $row){
      
        $data = stristr($row['text'], 'src="'); // Stripping all data from before $start
        $data = substr($data, strlen('src="'));  // Stripping $start
        $stop = stripos($data, '/>');   // Getting the position of the $end of the data to scrape
        $img = substr($data, 0, $stop);    // Stripping all data from after and including the $end of the data to scrape
        $img = str_replace('"', '', $img);
        $string  = str_replace(' ', '', $img);
        $imgLink[] = preg_replace('/\s+/', '', $string);
        
    }
    
    
   if (!$wsql->query('SELECT * FROM * WHERE $class == "priceDisplay" || $class == "priceDisplaySale"')){
        print "Query error: " . $wsql->error; 
        exit;
    }
    
    foreach($wsql->fetch_array() as $row){
      
        $price[] = $row['text'];
       
    }
    
     if (!$wsql->query('SELECT * FROM * WHERE $class == "productItemName"')){
        print "Query error: " . $wsql->error; 
        exit;
    }
    
    foreach($wsql->fetch_array() as $row)
    {
     
        $productname = mysqli_real_escape_string($conn, $row['text']);
	if($productname==NULL)
	{
	    $productname = $row['text']; 
	}
	
$arsize = explode('<span',$productname);
//echo sizeof($arsize);

	$productlink = $row['href'];
        
        $priceArray=explode("$",$price[$i]);
	
        $productprice=trim($priceArray[1]);
	
        $productimage = 'http://www.gap.com'.$imgLink[$i];
        if(sizeof($arsize)>1)
{  $productname = substr($productname, 24, -7); 
	$productimage = substr($productimage, 0, -14);

} 
        $productsaleprice = '';
        $dataimg = $row['href'];
        $startimg = 'pid=';
        $endimg = '&vid=1';
      
        $dataimg = stristr($dataimg, $startimg); // Stripping all data from before $start
        $dataimg = substr($dataimg, strlen($startimg));  // Stripping $start
        $stop = stripos($dataimg, $endimg);   // Getting the position of the $end of the data to scrape
        $sourcePid = substr($dataimg, 0, $stop);
	/*
	 *Get Source product ID(Product Id on Website)
	 */
      
         $qrry = "SELECT `sourceProductId` FROM `productinfo` WHERE `categoryId` = '".$productCatid."' AND `sourceId` ='".$sourceId."'";
	 $querry = mysqli_query($conn, $qrry);
	 while ($row = mysqli_fetch_assoc($querry))
	 {
	     $array1[] = $row['sourceProductId'];
	     
	 }
        $qry = "SELECT `sourceProductId` FROM `productinfo` WHERE `sourceProductId`=".$sourcePid;
        $result = mysqli_query($conn, $qry);
        $retrive  = mysqli_fetch_row($result);
	 
	/*
	 *
	 *Fetch All Products form databse and check existing or not, 
	 *If Not than insert into database Otherwise Update product information into database
	 */
        if ($retrive[0] == NULL)
        {	if ($productsaleprice == NULL || $productsaleprice == "" || $productsaleprice == 00.00)
	       { $productsaleprice = $productprice;
	       }
           
            $qry1 = 'INSERT INTO `productinfo`( productName, productPrice, productSaleprice, productImage, productLink, categoryId, sourceProductId, sourceId)';
            $qry1.= 'VALUES ("'.$productname.'","'.$productprice.'","'.$productsaleprice.'","'.$productimage.'","'.$productlink.'","'.$productCatid.'","'.$sourcePid.'","'.$sourceId.'")';
            
	    
            $result11 = mysqli_query($conn, $qry1);
	    
	     
            $del[] = $sourcePid;
        }
         else
         {	if ($productsaleprice == NULL || $productsaleprice == "" || $productsaleprice == 00.00)
	       { $productsaleprice = $productprice;
	       }
            $qry2 ='UPDATE `productinfo` SET `productName`="'.$productname.'",`productPrice`="'.$productprice.'",`productSaleprice`="'.$productsaleprice.'",';
            $qry2.='`productImage`="'.$productimage.'",`productLink`="'.$productlink.'" WHERE `sourceProductId`='.$sourcePid;
            
            $result12 = mysqli_query($conn, $qry2);
            $del[] = $sourcePid;
	   
         }
         
      $i++;
    }

	    $dif = array_unique(array_diff($array1, $del));
	     foreach ($dif as $val)
	    {
		$qry3 = "DELETE FROM `productinfo` WHERE `sourceProductId`='".$val."' AND `sourceId`='2';";
	        $result3 = mysqli_query($conn, $qry3);
	    }
         
	     date_default_timezone_set("UTC");
            
	    $qry2 = "UPDATE `timetrigger` SET `lastUpdate`='".time()."',`sourceId`='1' WHERE `categoryId` = '".$productCatid."'";
         
	    $result2 = mysqli_query($conn, $qry2);
   } else
   {
  	   date_default_timezone_set("UTC");
            
	    $qry2 = "UPDATE `timetrigger` SET `lastUpdate`='".time()."',`sourceId`='1' WHERE `categoryId` = '".$productCatid."'";
         
	    $result2 = mysqli_query($conn, $qry2);
   }
            
  
  }

  unset($data);
  
  
  
  $qry ="SELECT * FROM `profile` WHERE `user_id`='$user_id' and `gen_id`='$genderId'";
  
   $resultss = mysqli_query($conn, $qry) or die (mysqli_error());
   $data1= mysqli_fetch_assoc($resultss);
/*
 * Fetch User's Profile
 */
	
$sizes="";
$colors="";
$profile=json_decode($data1['profile_data'],true);

foreach($profile as $cat_val){
   
   if($productCatid==$cat_val['id']) {
    
      $sizes=$cat_val['size'];
      $colors=$cat_val['colors'];
     
   }    
   
}

  $data=array();
 /*
       *Get Size and color form profile
       */
     if($sizes[0]=="-1" or $sizes=="-1")
      {
	$sizeName="";
      } elseif($sizes==NULL)
      {
	$sizeName="";
      }
      else
      {
	    foreach($sizes as $size_val)
	  { 
	    $sizeArray[] = $size_val['size'].'';
	  }
	   $sizeName = implode("','",$sizeArray);
      }
   if($colors[0]=="-1" or $colors=="-1")
   {
     $colorName="";
   } elseif($colors==NULL)
      {
	$colorName="";
      }
   else {  
       foreach($colors as $calar_val)
      {
	$colorArray[] = $calar_val['color_name']; 
      }
         $colorName = implode("','",$colorArray);
    } 
         
	 if($sizeName != NULL && $colorName != NULL)
	 {
            $clrqry = "SELECT DISTINCT (P1.productId) FROM productAttribute AS P1 INNER JOIN productAttribute AS P2 ON P1.productId = P2.productId where P1.AttributeValue IN('".$colorName."') and P2.AttributeValue IN('".$sizeName."')";
            $resultpId = mysqli_query($conn, $clrqry);
            if(mysqli_num_rows($resultpId)>1)
            {
               foreach($resultpId as $resultpIds)
               {      
                  $arraypIds[] = $resultpIds['productId']; 
               }
                  $arraypId = implode("','",$arraypIds);    
            } else
            {
                 foreach($resultpId as $resultpIds)
               {      
                  $arraypId = $resultpIds['productId']; 
               }
            }
            
	     $qryy = "SELECT DISTINCT (proinfo.productId), proinfo.* FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId";
             $qryy .= " WHERE proinfo.categoryId='".$productCatid."' AND proatt.productId in ('".$arraypId."')";
          }
         elseif($colorName != NULL)
	 {
	    $clrqry = "AND proatt.AttributeValue IN('".$colorName."')";
	    $qryy ="SELECT DISTINCT (proinfo.productId), proinfo.* FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$productCatid."'".$clrqry;
	 }
	 elseif($sizeName != NULL)
	 {
	    $sizeqry = "AND proatt.AttributeValue IN('".$sizeName."')";
	    $qryy ="SELECT DISTINCT (proinfo.productId), proinfo.* FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$productCatid."'".$sizeqry;
	 }
         else
	 {
	    $qryy ="SELECT * FROM `productinfo` WHERE `categoryId` = '".$productCatid."'"; // ORDER BY productSaleprice DESC LIMIT 100
	 }
	
	 $result21 = mysqli_query($conn, $qryy) or die (mysqli_error());
 	 
	 foreach($result21 as $row1)
	    {
	       $sourceId = $row1['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $info['productId'] = $row1['productId'];
	       $info['url'] = $row1['productLink'];
	       $info['img'] = $row1['productImage'];
	       $info['title'] = $row1['productName'];
	       $info['original_price'] = $row1['productPrice'];
	       $info['sale_price'] = $row1['productSaleprice'];
	       if($info['sale_price']!=""  && $info['original_price']!="")
		  {
		      $salep=(float)$info['sale_price'];
		      $orginalp=(float)$info['original_price'];
		       //discount=1-(sale price/original price);
		        $info['discount_off']=(string)((float) (100-(($salep / $orginalp)*100))) ;
		   
		  }
	       $data[]=$info;
	       
	    }
	  
	    
    $tocat_record=count($data);
if($tocat_record > 0)
{
     // shuffle($data);
     function cmp($a, $b)
      {
	  if ($a["sale_price"] == $b["sale_price"]) {
	      return 0;
	  }
	  return ($a["sale_price"] < $b["sale_price"]) ? -1 : 1;
      }
      
      function sort_discount($a, $b)
      {
	  if ($b["discount_off"] == $a["discount_off"]) {
	      return 0;
	  }
	  return ($b["discount_off"] > $a["discount_off"]) ? -1 : 1;
      }
      //usort($data,"cmp");
     
      if($filter=="yes" || $filter=="Yes" || $filter=="YES")
      { 
	  usort($data,"sort_discount");
          $data = array_reverse($data);
      } else
      { 
         usort($data,"cmp");   
      }
     
      
      $i=1;
      $tot=0;
      $file_url="";
      $url_data=array();
      foreach(array_chunk($data, 30) as $dataresult ) {
	
	 if($i > 1){
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $file_url["url"]=myhost."temp/".$user_id."_".$i.".json";
	    $url_data[]=$file_url;
	 }else{
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $datas=$dataresult;
	 }
	 $tot++;
	 $i++;
      }
      $response["error"] = 0;
      $response["success"] = 1;
      $response["total_record"] = $tocat_record;
      $response["host_url"]=myhost."temp/";
      $response["total_page"]=$tot;
      $response["files"] = $url_data;
      $response['product']=$datas;     
      $response["message"] = "Select Record Successfully!";
}
 else{
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "Product Not found";
   
}
 
echo json_encode($response);
	
         ?>