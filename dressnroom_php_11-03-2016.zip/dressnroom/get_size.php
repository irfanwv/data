<?php
$response=array();
$main_json_size=array();
$get_size=json_decode($_POST['cat_id_array'],true);

foreach($get_size as $value)
{
    $size_info="";
    $color_info="";
    $main_data="";
    
    $main_data['cat_id']="";
    $main_data['sizes']=array();
    $main_data['colors']=array();
    
    $cat_id=$value[cat_id];
    
   $qry ="SELECT * FROM `size_map` WHERE `product_id`='".$cat_id."'";
   $results = mysqli_query($conn, $qry) or die (mysqli_error());
   
    if(mysqli_num_rows($results) > 0)
    {
      while($data = mysqli_fetch_assoc($results)){
            
            $size_arr=array();
            
            $size_arr['size_id']=$data['id'];
            
            if($data['bonton_size']==""){
                $size_arr['name']=$data['express_size'];
            }
            else{
                $size_arr['name']=$data['bonton_size'];
            }
            $size_info[]=$size_arr;
        }  
    }
    
    //---------------------------------------------
    
    $qry ="SELECT * FROM `color_map` WHERE `product_id`='".$cat_id."'";
   $color_results = mysqli_query($conn, $qry) or die (mysqli_error());
   
    if(mysqli_num_rows($color_results) > 0)
    {
        while($data1 = mysqli_fetch_assoc($color_results))
        {
            $color_arr=array();
            
            $color_arr['color_id']=$data1['id'];
             
            if($data1['bonton_color']=="")
            {
                $color_arr['color_name']=$data1['express_color'];
            }
            else{
                $color_arr['color_name']=$data1['bonton_color'];
            }
            $color_arr['color_code']=$data1['color_code'];
            $color_info[]=$color_arr;
        }
        
        $main_data['colors']=$color_info;
        
    }
    //---------------------------------------------
    
    
    
    $main_data['cat_id']=$cat_id;
    if(empty($size_info)){
        
    }else{
        $main_data['sizes']=$size_info;
    }
    
    $main_json_size[]=$main_data;
   
}
//----------------color---------------------------


if(count($main_data) > 0){
   $response['error']=0;
   $response['success']=0;
   $response['size_list']=$main_json_size;
   $response['message']="Select size successfully";
   
}
else{
    $response['error']=0;
    $response['success']=0;
    $response['size_list']="";
    $response['message']=" size not available";
}

 /*print response in json format*/
echo json_encode($response);

?>