<?php

$user_id=$_POST['user_id'];
$gen_id=$_POST['gen_id'];
$saveCategory=$_POST['saveCategory'];

if( filter_var($user_id, FILTER_VALIDATE_INT) == true )
{
$numqry ="SELECT * FROM `profile` WHERE `user_id`='".$user_id."' and `gen_id`='".$gen_id."'";
$numdata = mysqli_query($conn, $numqry) or die (mysqli_error());
$count = mysqli_num_rows($numdata);
if($count > 0)
    {

	$qry ="UPDATE `profile` SET `saveCategory`='".$saveCategory."' WHERE `user_id`='".$user_id."' and `gen_id`='".$gen_id."'";
	$updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
                if($updatedata){
                    $response['error']= 0 ;
                    $response['success']= 1 ;
                    $response['message']= "Save Category Successfully!" ;        
                } else
		{
			$response["error"] 	= 1;
			$response["success"] 	= 0;    
			$response["message"] 	= "User Not Valid!";
		}
    } else
    {
	$insertQry ="INSERT INTO `profile`(`user_id`, `gen_id`, `saveCategory`) VALUES ('".$user_id."', '".$gen_id."', '".$saveCategory."') ";
	$insertdata = mysqli_query($conn, $insertQry) or die (mysqli_error());
		if($insertdata)
		{
                    $response['error']= 0 ;
                    $response['success']= 1 ;
                    $response['message']= "Save Category Successfully!" ;        
                } else
		{
			$response["error"] 	= 1;
			$response["success"] 	= 0;    
			$response["message"] 	= "Record Not Inserted!";
		}
    }
}else
{
	
}


/*print response in json format*/
echo json_encode($response);



?>