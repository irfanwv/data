<?php
$start = microtime(true);
ini_set('memory_limit', '-1');



$user_id=$_POST['user_id'];
$gen_id=$_POST['gen_id'];

   if(!empty($user_id) || $user_id!="")
   {

	 $qrry = "SELECT * FROM `profile` WHERE `user_id`='".$user_id."' and `gen_id`='".$gen_id."'";
	 $result = mysqli_query($conn, $qrry) or die (mysqli_error());
	  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
	    {
	       $info['saveCategory'] = $row['saveCategory'];
	    }
          
	 echo '{"tag":"get_category","error":0,"success":1,"productlist":['.$info['saveCategory'].'],"message":"Saved category list!"}';
   }else
   {
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "User Not Valid!";
      echo json_encode($response);
   }

      

exit;

?> 