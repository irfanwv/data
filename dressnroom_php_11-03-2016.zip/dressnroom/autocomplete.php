<?php
$response=array();
$keyword=$_POST['keyword'];
$gen_id=$_POST['gen_id'];
$table = "dr_map" ;

  $qry = "SELECT * FROM `categoryinfo` WHERE  `categoryName` LIKE '%".$keyword."%' and `genderId`='$gen_id' ORDER BY `categoryName` DESC";
          
$results = mysqli_query($conn, $qry) or die (mysqli_error());
$count=mysqli_num_rows($results);
if($count > 0)
{
    $data="";
    while($row = mysqli_fetch_assoc($results))
    {
        $detail=array();
        $detail['id']=$row['categoryId'];
        
        if($row['parentCategory']!="")
        {
            $qry = "SELECT * FROM `categoryinfo` WHERE `categoryId`='".$row['parentCategory']."'";
          
            $results1 = mysqli_query($conn, $qry) or die (mysqli_error());
            $count=mysqli_num_rows($results1);
           
            $c_id_name="";
            if($count > 0)
            {
                $row1 = mysqli_fetch_assoc($results1);
                $detail['keyword']=$row1['categoryName']." >> ".$row['categoryName'];
            }else{
                $detail['keyword']=$row['categoryName'];
            }
        }else{
             $detail['keyword']=$row['categoryName'];
        }
       
        
        $data[]=$detail;
    }
    $response['error']=0;
    $response['success']=1;
    $response["results"]=$data;
    $response['message']="List of categories!";
    
}else{
    $response['error']=1;
    $response['success']=0;
    $response['message']="Record Not Found!";

}

echo json_encode($response);

?>