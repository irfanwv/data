<?php
$start = microtime(true);

ini_set('memory_limit', '-1');



$user_id=$_POST['user_id'];
$productId=$_POST['productId'];

$data=array();
   if(!empty($user_id) || $user_id!="")
   {
/*
 * Fetch User's Profile
 * 
 */
       if(!empty($productId) || $productId!="")
      {
	 $qry = "DELETE FROM `productFavorite` WHERE `productId`='".$productId."' AND `id`='".$user_id."'";
	 $results = mysqli_query($conn, $qry) or die (mysqli_error());
	 
	 if($results!="")
	 {
	    $response["error"] = 0;
	    $response["success"] = 1;    
	    $response["message"] = "Product removed succefully!";
	 }else
	 {
	    $response["error"] = 1;
	    $response["success"] = 0;    
	    $response["message"] = "Product Not removed!";
	 }
      } else
      {
	$response["error"] = 1;
	$response["success"] = 0;    
	$response["message"] = "Empty Product Id!";
      }
      
      
   }else
   {
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "User Not Valid!";
   }

echo json_encode($response);
exit;

?> 