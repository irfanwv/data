<?php

/*
 *
 *This is Cronjob file, It is reset the current counter of every category in given time.
 */
require 'db_conf.php';

$productCatid=5;

$resultt = mysqli_query($conn, "SELECT * FROM `timetrigger` WHERE `categoryId` = $productCatid");
$crow = mysqli_fetch_assoc($resultt);
 $attributeUpdate = $crow['attributeUpdate'];
 $attributeUpdate = $attributeUpdate + 21600;
 //echo $attributeUpdate.'='.time().'<br>';
 
    if(time() > $attributeUpdate)
      {

        $insertqry ="UPDATE `timetrigger` SET `currentCounter` = 0, `attributeUpdate`='".time()."'"; //for update current counter
        
        $result = mysqli_query($conn, $insertqry);
       // echo $result;
      }
      

 ?>