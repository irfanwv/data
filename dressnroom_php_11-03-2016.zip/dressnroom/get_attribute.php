 <?php $start = microtime(true); ?> 
<?php

require 'simple_html_dom.php';
require 'db_conf.php';
    $productCatid = $_GET['categoryId'];
    $genderId = $_GET['genId'];
    $update = $_GET['update'];
    $user_id = $_GET['user_id'];
    $filter = $_GET['filter'];

   
    $qry ="SELECT * FROM `profile` WHERE `user_id`='$user_id' and `gen_id`='$genderId'";
  
   $resultss = mysqli_query($conn, $qry) or die (mysqli_error());
   $data1= mysqli_fetch_assoc($resultss);
   if(mysqli_num_rows($resultss)!=0)
   { 
    
      /*
       * Fetch User's Profile
       */
	      
      $sizes="";
      $colors="";
      $profile=json_decode($data1['profile_data'],true);
      
      foreach($profile as $cat_val)
      {
	 
	 if($productCatid==$cat_val['id'])
	 {
	  
	    $sizes=$cat_val['size'];
	    $colors=$cat_val['colors'];
	   
	 }    
	 
      }
      
      
      $data=array();
      
      /*
       *Get Size and color form profile
       */
     if($sizes[0]=="-1" or $sizes=="-1")
      {
	$sizeName="";
      } elseif($sizes==NULL)
      {
	$sizeName="";
      }
      else
      {
	    foreach($sizes as $size_val)
	  { 
	    $sizeArray[] = $size_val['size'].'';
	  }
	   $sizeName = implode("','",$sizeArray);
      }
      if($colors[0]=="-1" or $colors=="-1")
      {
	$colorName="";
      } elseif($colors==NULL)
	 {
	   $colorName="";
	 }
      else {  
	  foreach($colors as $calar_val)
	 {
	   $colorArray[] = $calar_val['color_name']; 
	 }
	    $colorName = implode("','",$colorArray);
       }
   }
	 if($sizeName != NULL && $colorName != NULL)
	 {
            $clrqry = "SELECT DISTINCT (P1.productId) FROM productAttribute AS P1 INNER JOIN productAttribute AS P2 ON P1.productId = P2.productId where P1.AttributeValue IN('".$colorName."') and P2.AttributeValue IN('".$sizeName."')";
            $resultpId = mysqli_query($conn, $clrqry);
            if(mysqli_num_rows($resultpId)>1)
            {
               foreach($resultpId as $resultpIds)
               {      
                  $arraypIds[] = $resultpIds['productId']; 
               }
                  $arraypId = implode("','",$arraypIds);    
            } else
            {
                 foreach($resultpId as $resultpIds)
               {      
                  $arraypId = $resultpIds['productId']; 
               }
            }
            
	     $qryy = "SELECT DISTINCT (proinfo.productId), proinfo.* FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId";
             $qryy .= " WHERE proinfo.categoryId='".$productCatid."' AND proatt.productId in ('".$arraypId."')";
            
	 }
         elseif($colorName != NULL)
	 {
	    $clrqry = "AND proatt.AttributeValue IN('".$colorName."')";
	    $qryy ="SELECT DISTINCT (proinfo.productId), proinfo.* FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$productCatid."'".$clrqry;
	 }
	 elseif($sizeName != NULL)
	 {
	    $sizeqry = "AND proatt.AttributeValue IN('".$sizeName."')";
	    $qryy ="SELECT DISTINCT (proinfo.productId), proinfo.* FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$productCatid."'".$sizeqry;
	 }
         else
	 {
	    $qryy ="SELECT * FROM `productinfo` WHERE `categoryId` = '".$productCatid."'"; // ORDER BY productSaleprice DESC LIMIT 100
	 }
	
	 $result21 = mysqli_query($conn, $qryy) or die (mysqli_error());
 	
	 foreach($result21 as $row1)
	    {
	       $sourceId = $row1['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $info['productId'] = $row1['productId'];
	       $info['url'] = $row1['productLink'];
	       $info['img'] = $row1['productImage'];
	       $info['title'] = $row1['productName'];
	       $info['original_price'] = $row1['productPrice'];
	       $info['sale_price'] = $row1['productSaleprice'];
	       $info['discount_off']= 0;
		  if($info['sale_price']!=""  && $info['original_price']!="")
		  {
		      $salep=(float)$info['sale_price'];
		      $orginalp=(float)$info['original_price'];
		      $info['discount_off']=(string)((float) (100-(($salep / $orginalp)*100))) ;
		   
		  }
	       $data[]=$info;
	       
	    }
	  
	    
            
                  
                     
    $tocat_record=count($data);
if($tocat_record > 0)
{
     // shuffle($data);
     function cmp($a, $b)
      {
	  if ($a["sale_price"] == $b["sale_price"]) {
	      return 0;
	  }
	  return ($a["sale_price"] < $b["sale_price"]) ? -1 : 1;
      }
      
      function sort_discount($a, $b)
      {
	  if ($b["discount_off"] == $a["discount_off"]) {
	      return 0;
	  }
	  return ($b["discount_off"] > $a["discount_off"]) ? -1 : 1;
      }
      
     // usort($data,"cmp");  
      if($filter=="yes" || $filter=="Yes" || $filter=="YES")
      { 
	  usort($data,"sort_discount");
          $data = array_reverse($data);
      } else
      { 
         usort($data,"cmp");   
      }
     
      
      $i=1;
      $tot=0;
      $file_url="";
      $url_data=array();
      foreach(array_chunk($data, 30) as $dataresult ) {
	
	 if($i > 1){
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $file_url["url"]=myhost."temp/".$user_id."_".$i.".json";
	    $url_data[]=$file_url;
	 }else{
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $datas=$dataresult;
	 }
	 $tot++;
	 $i++;
      }
      $response["error"] = 0;
      $response["success"] = 1;
      $response["total_record"] = $tocat_record;
      $response["host_url"]=myhost."temp/";
      $response["total_page"]=$tot;
      $response["files"] = $url_data;
      $response['product']=$datas;     
      $response["message"] = "Select Record Successfully!";
}
 else{
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "Product Not found";
   
}
 
echo json_encode($response);
	
	 

/*
 *
 *Start Getting Size and Color
 *
 */


$resultt = mysqli_query($conn, "SELECT * FROM `timetrigger` WHERE `categoryId` = $productCatid");
$crow = mysqli_fetch_assoc($resultt);
 $currentCounter = $crow['currentCounter'];
 $attributeCounter = $crow['attributeCounter'];

if($attributeCounter > $currentCounter)
{
      $updateCounter = $currentCounter*50;
      $currentCounter = $currentCounter+1;
 
$pro = array();
$ch = array();
$link = array();
    $insertqry .="UPDATE `timetrigger` SET `currentCounter`=$currentCounter WHERE `categoryId`=$productCatid;"; //for update current counter
    // Defining the basic cURL function
    $queery = "SELECT `productId`, `productLink` FROM `productinfo` WHERE `categoryId`='".$productCatid."' AND `sourceId`=1 LIMIT ".$updateCounter." , 50";
   
$resullt = mysqli_query($conn, $queery);
 $plimit = mysqli_num_rows($resullt);
 while ($roww = mysqli_fetch_assoc($resullt))
{
  $link[]='http://www.bonton.com'.$roww['productLink'];
  $pro[] = $roww['productId'];
 }

   $ch_1 = curl_init($link7);
  for($i=0;$i<$plimit;$i++)
  {
      $ch[$i]= curl_init($link[$i]);
      curl_setopt($ch[$i], CURLOPT_RETURNTRANSFER, true);
  } 
  
  
  // build the multi-curl handle, adding both $ch
  $mh = curl_multi_init();
  for($i=0;$i<$plimit;$i++)
  {
    curl_multi_add_handle($mh, $ch[$i]);
  }
  
  
  // execute all queries simultaneously, and continue when all are complete
  $running = null;
  do {
    curl_multi_exec($mh, $running);
  } while ($running);
  
  // all of our requests are done, we can now access the results
 for($iii=0;$iii<$plimit;$iii++)
      {
       $scraped_page = curl_multi_getcontent($ch[$iii]);

  


  
    $html = new simple_html_dom();
    $color = array();
    $size = array();
    $array1= array();
    $array2= array();
    $productId = $pro[$iii];
   
// Load HTML from a string
$html->load($scraped_page);
    
   foreach($html->find('input#compositeProductId') as $element) 
     $sourcePid = $element->value;
     
     
   foreach($html->find('div[class=definingAttributes]') as $element) 
      $productprice = $element->outertext;
     
     
     //color_swatch
     
   foreach($html->find('div[id=swatch_selection_list_entitledItem_'.$sourcePid.'_Color]') as $elements)
      
      foreach($elements->find('ul') as $ul) 
      {
	     foreach($ul->find('li') as $li) 
	     {
		  
		  $imgLink[] = $li->find('a img', 0)->src;
		  $color[]   = $li->find('a img', 0)->alt;
	     }
      }
      	    //Get size by this
   foreach($html->find('div[class=color_swatch]') as $elementt) 
	    $size[] = $elementt->plaintext;
      
    
/*
 *Insert & Delete Size form database.
 *Run this query for getting product Id from database.1984681
 */      

if(count($size) > 0)
  {
      $qry = "SELECT * FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE proatt.AttributeName = 'Size' AND proinfo.sourceProductId = ".$sourcePid;
      $result = mysqli_query($conn, $qry);
      
       while ($row = mysqli_fetch_assoc($result))
      {
            $array1[] = $row['AttributeValue'];
      }
      $size = array_unique($size);
      $add = array_diff($size, $array1);
      $del = array_diff($array1, $size);

      if(count($del) > 0)
      {
           
           foreach($del as $delSize)
          {
            $qrry = "DELETE FROM `productAttribute` WHERE `productId`=".$productId."AND `AttributeValue`=".$delSize;
            $result1 = mysqli_query($conn, $qrry);
           
          }
      }
     
      if(count($add) > 0)
      {    foreach($size as $sizes)
          {
            $insertqry .= "INSERT INTO `productAttribute`(`productId`, `AttributeName`, `AttributeValue`) VALUES ('".$productId."','Size','".$sizes."');";
          }
      }
  }
      
/*
 *Insert & Delete Color form database.
 *Run this query for getting product Id from database.
 */      

if(count($color) > 0)
  {
      $qry1 = "SELECT * FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE  proatt.AttributeName = 'Color' AND proinfo.sourceProductId = ".$sourcePid;
      $result1 = mysqli_query($conn, $qry1);

      while ($row = mysqli_fetch_assoc($result1))
     {
           $array2[] = $row['AttributeValue'];
           $productId = $row['productId'];
           
     }
 
      $color = array_unique($color);
      $addd = array_diff($color, $array2);
      $dell = array_diff($array2, $color);

       if(count($dell) > 0)
      {
      
           
           foreach($dell as $delColor)
          {
            $qrry = "DELETE FROM `productAttribute` WHERE `productId`=".$productId."AND `AttributeValue`=".$delColor;
            $result1 = mysqli_query($conn, $qrry);
          }
      }   
       if(count($addd) > 0)
      { $ii=0;
            foreach($color as $Colors)
          {
            $insertqry .= "INSERT INTO `productAttribute`(`productId`, `AttributeName`, `AttributeValue`, `colorImage`) VALUES ('".$productId."','Color','".$Colors."', '".$imgLink[$ii]."');";
            $ii++;
          }
      }
  }
  unset($imgLink);
}

$star = mysqli_multi_query($conn, $insertqry);

}
      
 ?>