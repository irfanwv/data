<?php
$start = microtime(true);
ini_set('memory_limit', '-1');

include_once("simple_html_dom.php");

$data=array();
$response=array();
$del = array();
$array1 = array();
$bonton_url="";
$bonton_size_url="";
$bonton_color_url="";
$express_size="";
$express_size2="";
$express_color="";
$express_color2="";
$expsuccess="";
$btnsuccess="";
$sourceId = 1;
$product_id=$_POST['product_id'];
$gen_id=$_POST['gen_id'];
$user_id=$_POST['user_id'];
if(isset($_POST['filter']) && $_POST['filter']=="discount" )
{
   $filter="Yes";
} else {
    $filter="NO";
}


   $qry ="SELECT * FROM `profile` WHERE `user_id`='$user_id' and `gen_id`='$gen_id'";
   $resultss = mysqli_query($conn, $qry) or die (mysqli_error());
   $data1= mysqli_fetch_assoc($resultss);
/*
 * Fetch User's Profile
 */
	
$sizes="";
$colors="";
$profile=json_decode($data1['profile_data'],true);

foreach($profile as $cat_val){
   
   if($product_id==$cat_val['id']){
      $sizes=$cat_val['size'];
      $colors=$cat_val['colors'];;
   }
   
}


 
	$qry = "SELECT * FROM `timetrigger` WHERE `categoryId`='".$product_id."'";       
        $result = mysqli_query($conn, $qry);
        $retrive = mysqli_fetch_row($result);
       /*
        * Set Time trigger for updation
        */
        $interval = time() - $retrive[1];
         
if(900 <= $interval) //if data need update
{
	         
	    if($retrive[2] == 2)
	    {    
	       /*
	        *Frequently Data update if $retrive[2] ==1 than update from bonton else gap
	        */
	       header('Location: gap_data.php?categoryId='.$product_id.'&user_id='.$user_id.'&genId='.$gen_id.'&filter='.$filter.'&update=yes');
	       exit;
	    }
              

$category="";
	 
	 
$qry1 ='';
$qry2 ='';
$qry3 ='';
	 $qry ="SELECT catmap.* FROM `categoryMapping` as catmap INNER JOIN `categoryinfo` as catinfo ON catmap.categoryId = catinfo.categoryId WHERE catinfo.categoryId='$product_id' AND catmap.sourceId = '$sourceId'";
	   
	 $results = mysqli_query($conn, $qry) or die (mysqli_error());                                           
	 $data2=mysqli_fetch_assoc($results);
	 
	 $qrry = "SELECT `sourceProductId` FROM `productinfo` WHERE `categoryId` = '".$product_id."' AND `sourceId` ='".$sourceId."'";

    $querry = mysqli_query($conn, $qrry);
    while ($row = mysqli_fetch_assoc($querry))
    {
        $array1[] = $row['sourceProductId'];
	
    }
   
$gender=$gen_id;
$category=$data2["categoryUrl"];

if(isset($_POST['filter']) && $_POST['filter']=="discount" )
{
   $filter="Yes";
}



//==============================================================
if($gender==1)
{   
   $gender="men";
}
elseif($gender==2)
{
   $gender="women";
}
else
{
   $gender="baby-kids";
}
$url1="";
$url1="http://www.bonton.com/sc1/$gender/".$category;


$endmap = substr($category, -1);
if($endmap== '/') { } else { $url1 = $url1.'/'; }
                                             
$html="";
$url1 = $url1."?pageNum=&pageSize=100";
//echo $url1; exit;
if($url1!=''){
 
  $html = @file_get_html($url1);
  
}

if($html!="")
{
  
      foreach($html->find('ul.productListings') as $element)
      {    
       foreach($element->find('li') as $val)
	   {
	       $info=array();
	       
	       $info['brand']="bonton";
	       $info['url']=$val->find('div a', 0)->href;
	       $info['img']=$val->find('div a img', 0)->src;
	       $info['title']=$val->find('div a img', 0)->alt;
	       //$dataimg = $val->find('div a[class=button plainBtn quickViewBtn]', 0)->href;
	       $dataimg = $val->find('a[class=quickview-link]', 0)->href;
	       $info['original_price']="";
	       $info['end_price']="";
	       $productCatid = "";
	       
	       //----------------------sale Price-------------------------------------
	       if($dataf=$val->find('span[class=salePrice]', 0))
	       {
		   $sale=$dataf->plaintext;
		   $sale_data=explode("$",$sale);
		   
		  $info['sale_price']=preg_replace('/[^0-9.]/u', '',trim($sale_data[1]));
		   if (strpos($sale,'-') !== false)
		   {
		       $btnsalestr=explode("-",$sale);		  
		       $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnsalestr[0]));
		       $info['end_sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnsalestr[1]));
     		   }else{
		       $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($sale));
		       $info['end_sale_price']="";
		   }
		   
		   
		  $original=$val->find('span[class=price]', 0)->plaintext;
		  if (strpos($original,'-') !== false)
		  {
		      $btnstr=explode("-",$original);		  
		      $info['original_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[0]));
		      $info['end_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[1]));
    		  }else{
		      $info['original_price']=preg_replace('/[^0-9.]/u', '', trim($original));
		      $info['end_price']="";
		  }
		   
		   
		   
	       }
	       else{
		 	       
	        //---------------------------original price------------------------------------------
		     $original=$val->find('span[class=price]', 0)->plaintext;
		     if (strpos($original,'-') !== false)
		     {
			 $btnstr=explode("-",$original);		  
			 $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[0]));
			 $info['end_sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[1]));
       		     }else{
			 $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($original));
			 $info['end_sale_price']="";
		     }
	       
	       }
 	      
	       
	       //----------------------Discount------------------------------
	       
	       $info['discount_off']= 0;
	       if($info['sale_price']!=""  && $info['original_price']!="")
	       {
		   $salep=(float)$info['sale_price'];
		   $orginalp=(float)$info['original_price'];
		    //discount=1-(sale price/original price);
		    $info['discount_off']=(string)((float) (100-(($salep / $orginalp)*100))) ;
		
	       }
	       if($info['sale_price']!="" && $info['sale_price'] > 0)
	       $data[]=$info;
	       
	       
	       $price = $val->find('span[class=price]', 0)->plaintext;
	       $priceArray=explode("$",$price);
	       $productprice=trim($priceArray[1]); 
	       $startimg = 'productId=';
	       $endimg = '&';
	     $dataimg = stristr($dataimg, $startimg); // Stripping all data from before $start
	     $dataimg = substr($dataimg, strlen($startimg));  // Stripping $start
	     $stop = stripos($dataimg, $endimg);   // Getting the position of the $end of the data to scrape
	      $sourcePid = substr($dataimg, 0, $stop);    // Stripping all data from after and including the $end of the data to scrape
	      $productname = $info['title'];
	      $productimage = $info['img'];
	      $productlink = $info['url'];
	      $productsaleprice = $info['sale_price'];
	      $qry = "SELECT `sourceProductId` FROM `productinfo` WHERE `sourceProductId`=".$sourcePid;
	     $result = mysqli_query($conn, $qry);
	     $retrive  = mysqli_fetch_row($result);
	    $productId = $retrive[0];
	    
        if ($retrive[0] == NULL)
        {	if ($productsaleprice == NULL || $productsaleprice == "" || $productsaleprice == 00.00)
	       { $productsaleprice = $productprice;
	       }
            
            $qry1 .= "INSERT INTO `productinfo`( `productName`, `productPrice`, `productSaleprice`, `productImage`, `productLink`, `productColor`, `productSize`, `categoryId`, `sourceProductId`, `sourceId`)";
            $qry1 .= 'VALUES ("'.$productname.'","'.$productprice.'","'.$productsaleprice.'","'.$productimage.'","'.$productlink.'","'.$color.'","'.$size.'","'.$data2['categoryId'].'","'.$sourcePid.'","'.$sourceId.'");';
            $del[] = $sourcePid;
            
        }
         else
         { 	
	  if ($productsaleprice == NULL || $productsaleprice == "" || $productsaleprice == 00.00)
	       { $productsaleprice = $productprice;
	       }
            $qry2 .='UPDATE `productinfo` SET `productName`="'.$productname.'",`productPrice`="'.$productprice.'",`productSaleprice`="'.$productsaleprice.'", `productImage`="'.$productimage.'",`productLink`="'.$productlink.'",`categoryId`="'.$data2['categoryId'].'"';
            $qry2 .=' WHERE `sourceProductId`='.$sourcePid.';';
	   
            
            $del[] = $sourcePid;
           
	    
         }    
	    }
      }
      
	   
    $dif = array_unique(array_diff($array1, $del));

	     foreach ($dif as $val)
	    {
	        $qry31 = "DELETE FROM `productinfo` WHERE `sourceProductId`='".$val."' AND `sourceId`='1';";
		
	      $result3 = mysqli_query($conn, $qry31);
	    }

    $result1 = mysqli_multi_query($conn, $qry1);
    
    $qry2 .= "UPDATE `timetrigger` SET `lastUpdate`='".time()."',`sourceId`='2' WHERE `categoryId` = '".$data2['categoryId']."';";
    
    $result2 = mysqli_multi_query($conn, $qry2);

    header('Location: gap_data.php?categoryId='.$product_id.'&user_id='.$user_id.'&genId='.$gen_id.'&filter='.$filter.'&update=no'); 
    exit; // exit after bonton product update and redirect to gap_data.php for show product list. 
      
}


}
 $query = mysqli_query($conn, "SELECT count(*) as count FROM `productinfo` WHERE categoryId = '$product_id'") or die (mysqli_error());
 $row = mysqli_fetch_array($query);
 
$plimit = ($row['count']/50);
if (is_float($plimit))
{
     $plimit = (int)($plimit+1); 
}

 $qry11 = "UPDATE `timetrigger` SET `attributeCounter`='$plimit' WHERE `categoryId`=".$product_id;
mysqli_query($conn, $qry11);


      header('Location: get_attribute.php?categoryId='.$product_id.'&user_id='.$user_id.'&genId='.$gen_id.'&filter='.$filter.'&update=no');

      /*
       *Get Size and color form profile
       */
      if($sizes[0]=="-1" or $sizes=="-1")
     {
      $sizeName="";
      } else {
      foreach($sizes as $size_val)
      { 
	 $sizeArray[] = $size_val['size'].'';
      }
       $sizeName = implode("','",$sizeArray);
   }
   if($colors[0]=="-1" or $colors=="-1")
   {
     $colorName="";
   } else {  
       foreach($colors as $calar_val)
      {
	$colorArray[] = $calar_val['color_name']; 
      }
         $colorName = implode("','",$colorArray);
    } 
	 
       if($sizeName != NULL && $colorName != NULL)
	 {    
	     $qry ="SELECT DISTINCT (proinfo.productId), proinfo.productName, proinfo.productPrice, proinfo.productSaleprice, proinfo.productImage, proinfo.productLink, proinfo.productColor, proinfo.productSize, proinfo.categoryId, proinfo.sourceProductId, proinfo.sourceId FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$product_id."' AND proatt.AttributeValue IN('".$colorName.",".$sizeName."')";
	     
	 }
       elseif($colorName != NULL)
	 {
	    
	    $clrqry = "AND proatt.AttributeValue IN('".$colorName."')";
	    $qry ="SELECT DISTINCT (proinfo.productId), proinfo.productName, proinfo.productPrice, proinfo.productSaleprice, proinfo.productImage, proinfo.productLink, proinfo.productColor, proinfo.productSize, proinfo.categoryId, proinfo.sourceProductId, proinfo.sourceId FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$product_id."'".$clrqry;
	 }
	 elseif($sizeName != NULL)
	 {
	    $sizeqry = "AND proatt.AttributeValue IN('".$sizeName."')";
	    $qry ="SELECT DISTINCT (proinfo.productId), proinfo.productName, proinfo.productPrice, proinfo.productSaleprice, proinfo.productImage, proinfo.productLink, proinfo.productColor, proinfo.productSize, proinfo.categoryId, proinfo.sourceProductId, proinfo.sourceId FROM `productinfo` as proinfo INNER JOIN productAttribute as proatt ON proinfo.productId=proatt.productId WHERE proinfo.categoryId='".$product_id."'".$sizeqry;
	 }
         else
	 {
	    $qry ="SELECT * FROM `productinfo` WHERE `categoryId` = '".$product_id."'"; // ORDER BY productSaleprice DESC LIMIT 100
	 }
	
	
	 $query = mysqli_query($conn, $qry) or die (mysqli_error());
 	   
	 while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC))
	    {
	       $sourceId = $row['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $info['productId'] = $row['productId'];
	       $info['url'] = $row['productLink'];
	       $info['img'] = $row['productImage'];
	       $info['title'] = $row['productName'];
	       $info['original_price'] = $row['productPrice'];
	       $info['sale_price'] = $row['productSaleprice'];
	       
	       $data[]=$info;
	    }
	    

$tocat_record=count($data);
if($tocat_record > 0)
{
     // shuffle($data);
     function cmp($a, $b)
      {
	  if ($a["sale_price"] == $b["sale_price"]) {
	      return 0;
	  }
	  return ($a["sale_price"] < $b["sale_price"]) ? -1 : 1;
      }
      
      function sort_discount($a, $b)
      {
	  if ($a["discount_off"] == $b["discount_off"]) {
	      return 0;
	  }
	  return ($a["discount_off"] > $b["discount_off"]) ? -1 : 1;
      }

      usort($data,"cmp");
      
      if($filter=="Yes"){
	  usort($data,"sort_discount");
      }
     
      
      $i=1;
      $tot=0;
      $file_url="";
      $url_data=array();
      foreach(array_chunk($data, 30) as $dataresult ) {
	
	 if($i > 1){
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $file_url["url"]=myhost."temp/".$user_id."_".$i.".json";
	    $url_data[]=$file_url;
	 }else{
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $datas=$dataresult;
	 }
	 $tot++;
	 $i++;
      }
      $response["error"] = 0;
      $response["success"] = 1;
      $response["total_record"] = $tocat_record;
      $response["host_url"]=myhost."temp/";
      $response["total_page"]=$tot;
      $response["files"] = $url_data;
      $response['product']=$datas;     
      $response["message"] = "Select Record Successfully!";
}
else{
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "Product Not found";
   
}
      
echo json_encode($response);
exit;

?> 