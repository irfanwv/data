<?php


// include your composer dependencies
require_once 'vendor/autoload.php';
//
//$client = new Google_Client();
//$client->setApplicationName("DressNRoom");
//$client->setDeveloperKey("AIzaSyAGM_zllPb_jIzTQTKxqgLsr_Ap0Hle4vU");

$client = new Google_Client();
$client->setAuthConfigFile('client_secret.json');
$client->addScope(Google_Service_Drive::DRIVE_METADATA_READONLY);
//$client->setRedirectUri('http://' . $_SERVER['HTTP_HOST'] . '/oauth2callback.php');

 $auth_url = $client->createAuthUrl();

header('Location: ' . $auth_url);
exit;
?>