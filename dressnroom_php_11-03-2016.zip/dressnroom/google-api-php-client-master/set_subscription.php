<?php


include '../db_conf.php';
date_default_timezone_set("UTC");
$handle = fopen('php://input','r');
$jsonInput = fgets($handle);
$decoded = json_decode($jsonInput,true);



$user_id=$_POST['user_id'];
$subscriptionType=$_POST['subscriptionType'];
$tokenId=$_POST['tokenId']; 

//TYPE1=trial
//TYPE2=30days
//TYPE3=1yr


	if($user_id!="" && !empty($user_id))
   {
	$qry ="SELECT * FROM `userSubscription` WHERE `userId`='".$user_id."'";
	
	$get_res = mysqli_query($conn, $qry) or die (mysqli_connect_error());
	$no_of_row=mysqli_num_rows($get_res);
	$gcmRow=mysqli_fetch_row($get_res);
	$subscriptionDate = date('Y-m-d H:i:s');
	$datetime1 = new DateTime();
	
	if($no_of_row > 0)
	{
		if($gcmRow[2] == 'TYPE1' && $subscriptionType == 'TYPE1')
		{
			    $response['error']= 1 ;
			    $response['success']= 0 ;
			    $response['message']= "You Are Already on Trail Period!" ; 
		}elseif($gcmRow[2] == 'TYPE2' && $subscriptionType == 'TYPE1')
		{
			    $response['error']= 1 ;
			    $response['success']= 0 ;
			    $response['message']= "You Are Already on Trail Period!" ; 
			
		}
		elseif($gcmRow[2] == 'TYPE3' && $subscriptionType == 'TYPE1')
		{
			    $response['error']= 1 ;
			    $response['success']= 0 ;
			    $response['message']= "You Are Already on Trail Period!" ; 
			
		}
		else
		{   } //no trail user
			 $updateQry ="UPDATE `userSubscription` SET `subscriptionType`='".$subscriptionType."',`subscriptionDate`='".$subscriptionDate."', `tokenId`='".$tokenId."' WHERE `userId`='".$user_id."'";
			$updatedata = mysqli_query($conn, $updateQry) or die (mysqli_error());
			if($updatedata)
			{
				if($subscriptionType == 'TYPE1' || $subscriptionType == 'TYPE2')
				{
					$exp1 = date('Y-m-d', strtotime('+30 day', strtotime($subscriptionDate)));
				} else
				{
					$exp1 = date('Y-m-d', strtotime('+365 day', strtotime($subscriptionDate)));
				}
				$datetime2 = new DateTime($exp1);
				$interval = $datetime1->diff($datetime2);
				
				$response["subscription_type"] = $subscriptionType;
				$response['expriration_daysleft'] = $interval->d;
				$response["is_expired"] = 'false';
				$response['error']= 0 ;
				$response['success']= 1 ;
				$response['message']= "Update Successfully!" ;        
			}	

	}else
	{
		
		$qry ="INSERT INTO `userSubscription`(`userId`, `subscriptionType`, `subscriptionDate`, `tokenId`) VALUES ('".$user_id."','".$subscriptionType."','".$subscriptionDate."', '".$tokenId."')";
		$result = mysqli_query($conn, $qry);
		if($subscriptionType == 'TYPE1' || $subscriptionType == 'TYPE2')
		{
			$exp1 = date('Y-m-d', strtotime('+30 day', strtotime($subscriptionDate)));
		} else
		{
			$exp1 = date('Y-m-d', strtotime('+365 day', strtotime($subscriptionDate)));
		}
                    $datetime2 = new DateTime($exp1);
                    $interval = $datetime1->diff($datetime2);
                    
		    
		if($result!=false){
			//
		    $response["subscription_type"] = $subscriptionType;
                    if($interval->m){
                     $now = time(); // or your date as well
                    $your_date = strtotime($exp1);
                    $datediff =  $your_date-$now;
                    $response['expriration_daysleft'] = floor($datediff/(60*60*24));
                    } else
                    {
                       $response['expriration_daysleft'] = $interval->d; 
                    }
		    $response["is_expired"] = 'false';
                    $response["error"] = 0;
		    $response["success"] = 1;
		    $response["message"] = "Subscription Successfully!";
                    
                }else{
                    $response["error"] = 1;
		    $response["success"] = 0;
		    $response["message"] = "Insertion fail!";
                }
        }
   }else
   {
        $response["error"] = 1;
	$response["success"] = 0;
	$response["message"] = "Send Proper Data!";
   }
/*print response in json format*/
echo json_encode($response);



?>