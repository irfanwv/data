<?php
$client_id = '717676609075-kek3sf5ve69sjuk24oterj9iauovq4k7.apps.googleusercontent.com';
$redirect_uri = 'http://localhost:8888';
$client_secret = 'UlQeeZFS2dzuY_dRVu4mdKVx';

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://accounts.google.com/o/oauth2/token");

curl_setopt($ch, CURLOPT_POST, TRUE);

$code = $_REQUEST['code'];

// This option is set to TRUE so that the response
// doesnot get printed and is stored directly in
// the variable
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_POSTFIELDS, array(
'code' => $code,
'client_id' => $client_id,
'client_secret' => $client_secret,
'redirect_uri' => $redirect_uri,
'grant_type' => 'authorization_code'
));

echo $data = curl_exec($ch);

