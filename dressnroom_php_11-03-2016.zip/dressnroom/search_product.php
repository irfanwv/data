<?php

ini_set('memory_limit', '-1');

include_once("simple_html_dom.php");
$gen_id="";
if(isset($_POST['gen_id'])){
  $gen_id=$_POST['gen_id'];
}

 $productCatid = $_POST['categoryId'];
 $user_id=$_POST['user_id'];
 
$filter='';
if(isset($_POST['filter']) && $_POST['filter']!="")
{
  $filter=$_POST['filter'];  
}
 $qryy ="SELECT * FROM `productinfo` WHERE `categoryId` = '".$productCatid."'"; // ORDER BY productSaleprice DESC LIMIT 100
$result21 = mysqli_query($conn, $qryy) or die (mysqli_error());
 	 
	 foreach($result21 as $row1)
	    {
	       $sourceId = $row1['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $info['productId'] = $row1['productId'];
	       $info['url'] = $row1['productLink'];
	       $info['img'] = $row1['productImage'];
	       $info['title'] = $row1['productName'];
	       $info['original_price'] = $row1['productPrice'];
	       $info['sale_price'] = $row1['productSaleprice'];
	       
	       $data[]=$info;
	       
	    }


$tocat_record=count($data);
if($tocat_record > 0)
{
     // shuffle($data);
     function cmp($a, $b)
      {
	  if ($a["original_price"] == $b["original_price"]) {
	      return 0;
	  }
	  return ($a["original_price"] < $b["original_price"]) ? -1 : 1;
      }
      
      function sort_discount($a, $b)
      {
	  if ($a["discount_off"] == $b["discount_off"]) {
	      return 0;
	  }
	  return ($a["discount_off"] > $b["discount_off"]) ? -1 : 1;
      }

      usort($data,"cmp");
      if($filter!="")
      {
        usort($data,"sort_discount");
      }
      
      $i=1;
      $tot=0;
      $file_url="";
      $url_data=array();
      foreach(array_chunk($data, 30) as $dataresult ) {
	 if($i > 1){
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $file_url["url"]=myhost."temp/".$user_id."_".$i.".json";
	    $url_data[]=$file_url;
	 }else{
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $datas=$dataresult;
	 }
	 $tot++;
	 $i++;
      }
      $response["error"] = 0;
      $response["success"] = 1;
      $response["total_record"] = $tocat_record;
      $response["host_url"]=myhost."temp/";
      $response["total_page"]=$tot;
      $response["files"] = $url_data;
      $response['product']=$datas;     
      $response["message"] = "Select Record Successfully!";
}

else{
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "Product Not found";
   
}

echo json_encode($response);
?> 