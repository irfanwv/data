<?php

if($_POST['email']!="" && !empty($_POST['email']))
{
    $gcmId=$_POST['gcmId'];
    $deviceType=$_POST['deviceType'];

    $qry ='SELECT * FROM `registration` WHERE `email`="'.$_POST['email'].'" && `password`="'.md5($_POST['password']).'"';
    $login = mysqli_query($conn, $qry) or die (mysqli_error());
    $no_of_row=mysqli_num_rows($login);
    $row1 = mysqli_fetch_assoc($login);

        if($no_of_row==1)
    {
	$gcmqry ="SELECT `id` FROM `registration` WHERE `gcmId` = '".$_POST['gcmId']."'"; //Find GcmId in all users
	$gcmResult = mysqli_query($conn, $gcmqry) or die (mysqli_error());
	$no_row=mysqli_num_rows($gcmResult);
	if($no_row > 0)
	{
	   $gcmRow=mysqli_fetch_row($gcmResult);
	   $updateQry = "UPDATE `registration` SET `gcmId`='' WHERE `id`='".$gcmRow[0]."'";   //Delete GcmId
	   mysqli_query($conn, $updateQry);
	                        
	}
	/*   Profile code start  */
	$qry ='SELECT * FROM `profile` WHERE `user_id`="'.$row1['id'].'"';
	$profile = mysqli_query($conn, $qry) or die (mysqli_error());
	$no_of_rows=mysqli_num_rows($profile);
	$profile_created="No";
	if($no_of_rows > 0)
	{
	    $profileArray1 = array();
	    
	    $profile_created="Yes";
	    foreach($profile as $profileid)
	    {
		$profileArray1[] = $profileid['gen_id'];
	    }
	    
	}
	if($_POST['gcmId']!="" && !empty($_POST['gcmId']))
	{   
	    $qry ='UPDATE `registration` SET `login_status`= "1", `gcmId`="'.$_POST['gcmId'].'", `deviceType`="'.$deviceType.'" WHERE `id`="'.$row1['id'].'"';   //Update GcmId
	    $updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
	}
	$response["error"] = 0;
        $response["success"] = 1;
	$response["profile_created"] =$profile_created;
	$response["user_id"] = $row1['id'];	
        $response["email"] = $row1['email'];
        $response["message"] = "You Logged In Successfully";
	if($no_of_rows > 0)
	{
	    $response["gen_id"] = $profileArray1;
	}
    }    
    else
    {
	$response["error"] = 1;
	$response["success"] = 0;
	$response["message"] = "Invalid Username/Password";
    }
}
else
{
    /*print error message*/ 
    $response["error"] = 1;
    $response["success"] = 0;
    $response["message"] = "Send Proper Data!";
}

echo json_encode($response);
?>