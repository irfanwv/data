<?php

define('GOOGLE_API_KEY', 'AIzaSyCES1_yzWDG6_DN17tONXJWrYVouWUBkyg');

 function send_notification_iphone ($registatoin_ids, $data)
    { 
// Put your device token here (without spaces):

$deviceToken=$registatoin_ids;
// Put your private key's passphrase here:
$passphrase = "12345";

// Put your alert message here:
//$message = 'You have a notification!';
 $pem = 'ck.pem';

$ctx = stream_context_create();
stream_context_set_option($ctx, 'ssl', 'local_cert', $pem);
stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

// Open a connection to the APNS server
$fp = stream_socket_client(
	'ssl://gateway.sandbox.push.apple.com:2195', $err,
	$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

if (!$fp)
	exit("Failed to connect: $err $errstr" . PHP_EOL);

echo 'Connected to APNS' . PHP_EOL;

// Create the payload body

  $message['body'] = $data['body'];
 $body['aps'] = array( 'alert' => $message, 'type'=> $data['type'] );
  $body['badge'] =3;
   $body['sound'] ='cat.caf';
// Encode the payload as JSON
echo $payload = json_encode($body);

// Build the binary notification
$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
$result = fwrite($fp, $msg, strlen($msg));

if (!$result)
	echo 'Message not delivered' . PHP_EOL;
else
	echo 'Message successfully delivered' . PHP_EOL;

// Close the connection to the server
fclose($fp);
    }
    
    
    
    /* for andriod*/
    
    function send_notification($registration_ids,$resp)
    {   //Set POST variables
        $url = 'https://android.googleapis.com/gcm/send';
        
        $fields = array(
            'registration_ids' =>array($registration_ids),
        
	    'data'=> array( "message" => $resp),
        );
        $headers = array(
            'Authorization: key=' . GOOGLE_API_KEY,
            'Content-Type: application/json'
        );
        // Open connection
        $ch = curl_init();
        // Set the url, number of POST vars, POST data
       
	// Disabling SSL Certificate support temporarly
	
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        // Close connection
        curl_close($ch);
       //echo $result;
       return $result;
    }
   
    function send_notifications($registration_ids,$response) { // function send_notification($registatoin_ids, $message)

	// Set POST variables
	$url = 'https://android.googleapis.com/gcm/send';
	$fields = array(
	    'registration_ids' =>array($registration_ids),
	   //'user_ids' =>array($user_ids),
	    'data'=> array( "message" => $response),
	);
    
	$headers = array(
	    'Authorization: key=' . GOOGLE_API_KEY,
	    'Content-Type: application/json'	    
	);
	// Open connection
	$ch = curl_init();
    
	// Set the url, number of POST vars, POST data
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
        curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	// Disabling SSL Certificate support temporarly
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	
    
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    
	// Execute post
	$result = curl_exec($ch);
	if ($result === FALSE) {
	    die('Curl failed: ' . curl_error($ch));
	}
	
    
	// Close connection
	curl_close($ch);
	
	return $result;
    }
    
    ?>