<?php


$save_data=array();


$get_size=json_decode($_POST['profile_data'],true);

foreach($get_size as $data){
	$data_array=array();
	$data_array['id']=$data['id'];
	$data_array['colors']="";
	$data_array['size']="";
	if($data['colors'][0]=='-1'){
		$data_array['colors']=$data['colors'];               
	}
	else                                        
	{                                                             
		$color_arr_main=array(); 
		foreach($data['colors'] as $color){
			
			$colors_arr=array();
			
			if(!isset($color['color_id'])){
				     
				   
				$qry ="SELECT `id` FROM `color_map` WHERE `product_id` ='".$data['id']."' AND (`bonton_color`='".$color['color_name']."' OR `express_color`='".$color['color_name']."')";
				$get_color = mysqli_query($conn, $qry) or die ('Could not connect: ' .mysqli_error());
				
				$no_of_row=mysqli_num_rows($get_color);
				if($no_of_row > 0)
				{       $row= mysqli_fetch_assoc($get_color);
					
					$colors_arr['color_name']=$color['color_name'];
					$colors_arr['color_id']=$row['id'];
				}
				else{
					$colors_arr['color_name']=$color['color_name'];
					$colors_arr['color_id']="";
				}
				
			}
			else{               
				$colors_arr['color_name']=$color['color_name'];
				$colors_arr['color_id']=$color['color_id'];
				
			}
			if(empty($colors_arr)){
				
			}else{
				$color_arr_main[]=$colors_arr;
			}
			
		}
		
		$data_array['colors']=$color_arr_main;
	}
	
	if($data['size'][0]=='-1'){
		
		$data_array['size']=$data['size'];
	}
	else
	{
		$size_arr_main=array();
		foreach($data['size'] as $size){
			
			$sizes_arr=array();
			
			if(!isset($size['size_id'])){
				
				$qry ="SELECT `id` FROM `size_map` WHERE `product_id` ='".$data['id']."' AND `size_name`='".$size['size']."'";
				$res_size = mysqli_query($conn, $qry) or die (mysqli_error());
   				$no_of_row=mysqli_num_rows($res_size);
				if($no_of_row > 0)
				{
					$row=mysqli_fetch_assoc($res_size);
					
					$sizes_arr['size']=$size['size'];
					$sizes_arr['size-id']=$row['id'];
				}
				else{
					$sizes_arr['size']=$size['size'];
					$sizes_arr['size-id']="";
				}
				
			}
			else{
				$sizes_arr['size']=$size['size'];
				$sizes_arr['size-id']=$size['size_id'];
			}
			if(empty($sizes_arr)){
				
			}else{
				$size_arr_main[]=$sizes_arr;
			}
			
		}
		
		$data_array['size']=$size_arr_main;
	}
	
$save_data[]=$data_array;	
}

$profile=json_encode($save_data);

$user_id=$_POST['user_id'];
$gen_id=$_POST['gen_id'];

	
	$qry ="SELECT * FROM `profile` WHERE `user_id`='".$user_id."' and `gen_id`='".$gen_id."'";
	
	$get_res = mysqli_query($conn, $qry) or die (mysqli_error());
	$no_of_row=mysqli_num_rows($get_res);
	
	if($no_of_row > 0)
	{
	 $qry ="UPDATE `profile` SET `profile_data`='".$profile."' WHERE `user_id`='".$user_id."' and `gen_id`='".$gen_id."'";
	 $updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
                if($updatedata){
                    $response['error']= 0 ;
                    $response['success']= 1 ;
                    $response['message']= "Update Successfully!" ;        
                }

	}else
	{
		$qry ="INSERT INTO `profile`(`user_id`, `gen_id`, `profile_data`) VALUES ('".$user_id."','".$gen_id."','".$profile."')";
		$result = mysqli_query($conn, $qry) or die (mysqli_error());	
		if($result!=false){
                    $response["error"] = 0;
		    $response["success"] = 1;
		    $response["message"] = "Profile Create Successfully!";
                    
                }else{
                    $response["error"] = 1;
		    $response["success"] = 0;
		    $response["message"] = "Insertion fail!";
                }
        }
/*print response in json format*/
echo json_encode($response);



?>