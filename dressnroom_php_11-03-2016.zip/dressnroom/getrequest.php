<?php

require 'db_conf.php';
require 'simplepush.php';
 $tag = $_POST['tag'];
date_default_timezone_set("UTC");


if(isset($tag)){}else{ $tag = "none";}
$handle = fopen('php://input','r');
$jsonInput = fgets($handle);
$decoded = json_decode($jsonInput,true);




if(isset($tag) ||  $decoded['tag'])
{
    /*create object of class logsheet*/
      
       $response=array();
     
       $response['tag']=$tag;
       
       switch ($tag) {
	     
	      case "registration":	      
		     try
		      {
			  
			     require_once("registration.php");
			    
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
		     
	      case "reg_check":
	      
		     try
		      {
			    
			     require_once("reg_check.php");
			    
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "login":
		    // echo $_POST['email'].':';
		     try
		      {
			    
			     require_once("login.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "logout":
	     
		     try
		      {
			     require_once("logout.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	   
	      case "category":
	    
		     try
		      {
			     require_once("category.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	    
	      case "sub_category":
	    
		     try
		      {
			     require_once("sub_category.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	
	      case "get_product":
	  
		     try
		      {
			     require_once("get_product.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "bontonexpress":
	   
		     try
		      {
			     require_once("bontonexpress.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "be_product":
	      
		     try
		      {
			     require_once("be_product.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "profile":
	 
		     try
		      {
			     require_once("profile.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	      case "get_data":
	    
		     try
		      {
			     require_once("get_data.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	    
	      case "get_event":
	    
		     try
		      {
			     require_once("get_event.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	      
	      case "wishlist_price":
	     
		     try
		      {
			     require_once("wishlist_price.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	      
	       case "search_product":
	     
		     try
		      {
			     require_once("search_product.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	      case "get_maincategory":
	     
		     try
		      {
			     require_once("get_maincategory.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	      case "get_category":
	     
		     try
		      {
			     require_once("get_category.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "get_profile":
	     
		     try
		      {
			     require_once("get_profile.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	      case "get_size":
	     
		     try
		      {
			     require_once("get_size.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "set_profile":
	      
		     try
		      {
			     require_once("set_profile.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "set_profile2":
	      
		     try
		      {
			     require_once("set_profile2.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	     
	       case "view_profile":
	     
		     try
		      {
			     require_once("view_profile.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	      
	      case "get_details":
	     
		     try
		      {
			     require_once("get_details.php");
		      }
		       catch(Exception $e)
		      {
			      $response["message"]="File not found Please contact with administrator";
			      echo json_encode($response);
		      }
		      break;
	      case "get_data2":
	   
		   try
		    {
			   require_once("get_data2.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	       case "get_color":
	   
		   try
		    {
			   require_once("get_color.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	       case "autocomplete":
	   
		   try
		    {
			   require_once("autocomplete.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "get_size2":
	   
		   try
		    {
			   require_once("get_size2.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "get_size3":
	   
		   try
		    {
			   require_once("get_size3.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "set_profile3":
	   
		   try
		    {
			   require_once("set_profile3.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      
	      case "MyEvents":
	   
		   try
		    {
			   require_once("elegent.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	     case "elegant_product":
	   
		   try
		    {
			   require_once("get_data2.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "forgot_password":
	   
		   try
		    {
			   require_once("mail.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "view_profile1":
	   
		   try
		    {
			   require_once("view_profile1.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "get_favorite":
	   
		   try
		    {
			   require_once("get_favorite.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "set_subscription":
	   
		   try
		    {
			   require_once("set_subscription.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "get_subscription":
	   
		   try
		    {
			   require_once("get_subscription.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "remove_favorite":
	   
		   try
		    {
			   require_once("remove_favorite.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "set_category":
	   
		   try
		    {
			   require_once("set_category.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "get_category":
	   
		   try
		    {
			   require_once("get_category.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	      case "logout":
	   
		   try
		    {
			   require_once("logout.php");
		    }
		     catch(Exception $e)
		    {
			    $response["message"]="File not found Please contact with administrator";
			    echo json_encode($response);
		    }
		    break;
	           
		   
	      default:	      
		   echo "tag didn't matched !";    
	     
       }
}
else
{
	echo "Oops .....Invalid Access";
}
?>