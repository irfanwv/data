<?php

$user = 'dressnro_dressn';
$password = '8BS1E}2C9wT7'; //'lCcHGEqEp8eV';
$db = 'dressnro_dressnroom';
$host = 'localhost';
$port = 8888;
define('myhost','http://'.$_SERVER["HTTP_HOST"].'/~dressnroom/');
$conn = mysqli_connect($host, $user, $password, $db);
//mysql_connect(   "$host:$port", $user, $password) or die(mysql_error());
//$db_selected = mysql_select_db($db, $link) or die(mysql_error());
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//mysqli_query($conn, $sql)

?>