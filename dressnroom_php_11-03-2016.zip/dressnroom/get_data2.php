<?php
//error_reporting(-1);
//ini_set('display_errors', 'On');
ini_set('memory_limit', '-1');
   
include_once("simple_html_dom.php");

$data=array();
$response=array();
$info = array();

$expsuccess="";
$btnsuccess="";
$filter="NO";
$sourceId = 1;
$product_id=$_POST['product_id'];
$gen_id=$_POST['gen_id'];
$user_id=$_POST['user_id'];
if(isset($_POST['filter']) && $_POST['filter']=="discount" )
{
   $filter="Yes";
} else {
    $filter="NO";
}
$qry1 ='';
$qry2 ='';


 $qry = "SELECT * FROM `timetrigger` WHERE `categoryId`='".$product_id."'";
 
        $result = mysqli_query($conn, $qry);
        $retrive  = mysqli_fetch_row($result);
       
        $interval = time() - $retrive[1];
       
        if(900 <= $interval) //if data need update
        {

$category="";


	 $qry ="SELECT * FROM `categoryinfo` WHERE `categoryId`='$product_id' and `genderId`='$gen_id'";
	 
	 $results = mysqli_query($conn, $qry) or die (mysqli_error());
	 $data2=mysqli_fetch_assoc($results);
	 $qrry = "SELECT * FROM `categoryMapping` WHERE categoryId ='".$data2['categoryId']."' and `sourceId` ='".$sourceId."'"; // sourceId [Bonton =1, Gap=4]
	 $results = mysqli_query($conn, $qrry) or die (mysqli_error());
	 $data3=mysqli_fetch_assoc($results);

$gender=$gen_id;
$category=$data3["categoryUrl"];
$exp_category=$data3["categoryUrl"];
$edit_url="";
$main_expurl='http://www.express.com/';
$expurl=$main_expurl.$exp_category;    

$qrry = "SELECT `sourceProductId` FROM `productinfo` WHERE `categoryId` = '".$product_id."' AND `sourceId` ='".$sourceId."'";
    $querry = mysqli_query($conn, $qrry);
    while ($row = mysqli_fetch_assoc($querry))
    {
      $array1[] = $row['sourceProductId'];
	
    }
if(isset($_POST['filter']) && $_POST['filter']=="discount" )
{
   $filter="Yes";
}
//==============================================================
if($gender==1)
{   
   $gender="/men";
}
elseif($gender==2)
{
   $gender="/women";
}
else
{
   $gender="/baby-kids";
}



$btnurl="http://www.bonton.com/sc1$gender/".$category;
$url1="";
if($btnsuccess=="done"){
   
   if($bonton_url!=""){
  
    $url1="http://www.bonton.com/sc1$gender/".$category."/?".$bonton_url;
    $single_data="/sc1$gender/".$category."/?".$bonton_url;
   }else{
     // echo "not url";
      $url1="";
   }
}
else{
    $url1="http://www.bonton.com/sc1$gender/".$category;
    $single_data="/sc1$gender/".$category;
}


$html="";
//echo $url1; exit;
if($url1!=''){
 
  $html = @file_get_html($url1);
  
}

if($html!="")
{
  // echo 'sucess'; exit;
      foreach($html->find('ul.productListings') as $element)
      {    
       foreach($element->find('li') as $val)
	   {
	       $info=array();
	       
	       $info['brand']="bonton";
	       $info['url']=$val->find('div a', 0)->href;
	       $info['img']=$val->find('div a img', 0)->src;
	       $info['title']=$val->find('div a img', 0)->alt;
	       //$dataimg = $val->find('div a[class=button plainBtn quickViewBtn]', 0)->href;
	       $dataimg = $val->find('a[class=quickview-link]', 0)->href;
	       $productCatid = "";
	       
	       //----------------------sale Price-------------------------------------
	       if($dataf=$val->find('span[class=salePrice]', 0))
	       {
		   $sale=$dataf->plaintext;
		   $sale_data=explode("$",$sale);
		   
		  $info['sale_price']=preg_replace('/[^0-9.]/u', '',trim($sale_data[1]));
		   if (strpos($sale,'-') !== false)
		   {
		       $btnsalestr=explode("-",$sale);		  
		       $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnsalestr[0]));
		       $info['end_sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnsalestr[1]));
     		   }else{
		       $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($sale));
		       $info['end_sale_price']="";
		   }
		   
		   
		  $original=$val->find('span[class=price]', 0)->plaintext;
		  if (strpos($original,'-') !== false)
		  {
		      $btnstr=explode("-",$original);		  
		      $info['original_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[0]));
		      $info['end_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[1]));
    		  }else{
		      $info['original_price']=preg_replace('/[^0-9.]/u', '', trim($original));
		      $info['end_price']="";
		  }
		   
		   
		   
	       }
	       else{
	        //---------------------------original price------------------------------------------
		     $original=$val->find('span[class=price]', 0)->plaintext;
		     if (strpos($original,'-') !== false)
		     {
			 $btnstr=explode("-",$original);		  
			 $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[0]));
			 $info['end_sale_price']=preg_replace('/[^0-9.]/u', '', trim($btnstr[1]));
       		     }else{
			 $info['sale_price']=preg_replace('/[^0-9.]/u', '', trim($original));
			 $info['end_sale_price']="";
		     }
	       }
	       
	       //----------------------Discount------------------------------
	       
	       $info['discount_off']= 0;
	       if($info['sale_price']!=""  && $info['original_price']!="")
	       {
		   $salep=(float)$info['sale_price'];
		   $orginalp=(float)$info['original_price'];
		    
		    $info['discount_off']=(string)((int) (100-(($salep / $orginalp)*100))) ;
		
	       }
	       if($info['sale_price']!="" && $info['sale_price'] > 0)
	       $data[]=$info;
	       
	       
	       $price = $val->find('span[class=price]', 0)->plaintext;
	       $priceArray=explode("$",$price);
	       $productprice=trim($priceArray[1]); 
	       $startimg = 'productId=';
	       $endimg = '&';
	     $dataimg = stristr($dataimg, $startimg); // Stripping all data from before $start
	     $dataimg = substr($dataimg, strlen($startimg));  // Stripping $start
	     $stop = stripos($dataimg, $endimg);   // Getting the position of the $end of the data to scrape
	      $sourcePid = substr($dataimg, 0, $stop);    // Stripping all data from after and including the $end of the data to scrape
	      $sourcePid = $sourcePid.'122333';
	      $productname = $info['title'];
	      $productimage = $info['img'];
	      $productlink = $info['url'];
	      $productsaleprice = $info['sale_price'];
	      $qry = "SELECT `sourceProductId` FROM `productinfo` WHERE `sourceProductId`=".$sourcePid;
	     $result = mysqli_query($conn, $qry);
	     $retrive  = mysqli_fetch_row($result);
	       
	    
	    
        if ($retrive[0] == NULL)
        {
            
            $qry1 .= "INSERT INTO `productinfo`( `productName`, `productPrice`, `productSaleprice`, `productImage`, `productLink`, `productColor`, `productSize`, `categoryId`, `sourceProductId`, `sourceId`)";
            $qry1 .= 'VALUES ("'.$productname.'","'.$productprice.'","'.$productsaleprice.'","'.$productimage.'","'.$productlink.'","'.$color.'","'.$size.'","'.$data2['categoryId'].'","'.$sourcePid.'","'.$sourceId.'");';
            $del[] = $sourcePid;
            
        }
         else
         { 
            $qry2 .='UPDATE `productinfo` SET `productName`="'.$productname.'",`productPrice`="'.$productprice.'",`productSaleprice`="'.$productsaleprice.'", `productImage`="'.$productimage.'",`productLink`="'.$productlink.'"';
            $qry2 .=' WHERE `sourceProductId`='.$sourcePid.';';
            $del[] = $sourcePid;
           
         }
	    }
      }
	if(sizeof($array1)>0)
	{
	 $dif = array_unique(array_diff($array1, $del));
	  
	     foreach ($dif as $val)
	    {  
	      $qry31 = "DELETE FROM `productinfo` WHERE `sourceProductId`='".$val."' AND `sourceId`='1';";
		
	      $result3 = mysqli_query($conn, $qry31);
	    }
	 }
	 
    $result1 = mysqli_multi_query($conn, $qry1);
    $qry2 .= "UPDATE `timetrigger` SET `lastUpdate`='".time()."' WHERE `categoryId` = '".$data2['categoryId']."';";
    
    $result2 = mysqli_multi_query($conn, $qry2);
    header('Location: get_attribute.php?categoryId='.$product_id.'&filter='.$filter.'&update=no');
    
     
}
      
} else {
	  $qry ="SELECT * FROM `productinfo` WHERE `categoryId` = ".$product_id;
	  $query = mysqli_query($conn, $qry) or die (mysqli_error());
	  while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC))
	    {
	       $sourceId = $row['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $info['productId'] = $row['productId'];
	       $info['url'] = $row['productLink'];
	       $info['img'] = $row['productImage'];
	       $info['title'] = $row['productName'];
	       $info['original_price'] = $row['productPrice'];
	      $info['sale_price'] = $row['productSaleprice'];
	      $data[]=$info; 
	    }
	    
   
   }// end else if data update

//-------------------------------------------

$tocat_record=count($data);
if($tocat_record > 0)
{
     // shuffle($data);
     function cmp($a, $b)
      {
	  if ($a["sale_price"] == $b["sale_price"]) {
	      return 0;
	  }
	  return ($a["sale_price"] < $b["sale_price"]) ? -1 : 1;
      }
      
      function sort_discount($a, $b)
      {
	  if ($a["discount_off"] == $b["discount_off"]) {
	      return 0;
	  }
	  return ($a["discount_off"] > $b["discount_off"]) ? -1 : 1;
      }

      usort($data,"cmp");
      
      if($filter=="Yes"){
	  usort($data,"sort_discount");
      }
     
      
      $i=1;
      $tot=0;
      $file_url="";
      $url_data=array();
      foreach(array_chunk($data, 30) as $dataresult ) {
	 if($i > 1){
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $file_url["url"]=myhost."temp/".$user_id."_".$i.".json";
	    $url_data[]=$file_url;
	 }else{
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $datas=$dataresult;
	 }
	 $tot++;
	 $i++;
      }
      $response["error"] = 0;
      $response["success"] = 1;
      $response["total_record"] = $tocat_record;
      $response["host_url"]=myhost."temp/";
      $response["total_page"]=$tot;
      $response["files"] = $url_data;
      $response['product']=$datas;     
      $response["message"] = "Select Record Successfully!";
}
else{
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "Product Not found";
   
}

echo json_encode($response);
?> 