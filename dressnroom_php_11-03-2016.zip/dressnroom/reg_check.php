<?php
/*
 *This Web service is use for Device registertion check
 */
if(isset($_POST['device_id'])){    

    $device_id=$_POST['device_id'];
    
    
$qry = "SELECT `registration` FROM `productinfo` WHERE `device_id`='".$device_id."'";

    $check_device = mysqli_query($conn, $qry);
       
    $count = mysqli_num_rows($check_device);
    if($count > 0)
    {
        $response["error"] = 0;
        $response["success"] = 1;
        $response["found"] = "Yes";    
        $response["message"] = "Device already registered !";
    }
    else
    {
        $response["error"] = 0;
        $response["success"] = 1;
        $response["found"] = "No";
        $response["message"] = "Device don't registered !";
    }
}else{
    $response["error"] = 1;
    $response["success"] = 0;   
    $response["message"] = "Send proper data !";
}
/*print response in json format*/
echo json_encode($response);
?>