<?php

require_once('class.phpmailer.php');
include("class.smtp.php");

function sendmail($to,$subject,$message,$name)
    {
	
            $mail = new PHPMailer(); //defaults to using php "mail()"; the true param means it will throw exceptions on errors, which we need to catch
            try {
                $mail->SMTPDebug = 3;                               // Enable verbose debug output
               // $mail->isSMTP();
		$mail->CharSet = 'UTF-8';// Set mailer to use SMTP
                $mail->protocol = 'mail';		
                $mail->Host = 'ssl://smtp.gmail.com'; // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                             // Enable SMTP authentication
                $mail->Username   = "james01.matthew@gmail.com"; //"widevision.indore@gmail.com"; 
                $mail->Password   = "success@123"; //mahajan123";                     // SMTP password
                $mail->Port = 25;                                  // TCP port to connect, tls=587, ssl=465
                $mail->From = 'james01.matthew@gmail.com';
                $mail->FromName = $name; //'Detaxco';
                $mail->addAddress($to, $name);     // Add a recipient
                $mail->addReplyTo("no-reply@luvit.com",$name);
                $mail->WordWrap = 76;                                 // Set word wrap to 50 characters
                $mail->IsHTML(true);                                  // Set email format to HTML
                $mail->Subject = $subject;
                $mail->Body    = $message;
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                    $mail->Timeout = 3600; 
                if($mail->send()) {
                  
                    return 1;
                } else {
                   
                    return 0;
                }
                $errors[] = "Send mail sucsessfully";
            } catch (phpmailerException $e) {
                $errors[] = $e->errorMessage(); //Pretty error messages from PHPMailer
            } catch (Exception $e) {
                $errors[] = $e->getMessage(); //Boring error messages from anything else!
            }
    }
//======================================

$email = $_POST['email'];
$json = array();
function random_password($chars = 8) {
    $letters = 'abcefghijklmnopqrstuvwxyz1234567890';  //ABCDEFGHIJKLMNOPQRSTUVWXYZ
   return substr(str_shuffle($letters), 0, $chars);
} 
	$password = random_password();
	
	$qry ="SELECT * FROM `registration` WHERE `email`='".$email."'";
	$profile = mysqli_query($conn, $qry) or die (mysqli_error());
	$no_of_row=mysqli_num_rows($profile);
	
		    if($no_of_row > 0)
		    {     
		    $qry ='UPDATE `registration` SET `password`= "'.md5($password).'" WHERE `email`="'.$email.'"';
		    $updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
		    
			//$to="admondtx@gmail.com";
			 $subject="Password Forgotten Mail From DressNroom";
			 $body ="<div style=\"margin-left: 15%; margin-right: 20%; padding: 15px 0 15px 0; width: auto; min-width: 290px;\">";
			 
			 $body .="<p>Your Password Has Been Reset Successfully.</p>";
			 
			 
			$body .="<table border=\"1\" cellspacing=\"0\" cellpadding=\"5\" width=\"100%\">";
			$body .="<tr><td colspan=\"2\" align=\"center\" style=\"background-color: #214548;color: #fff;font-family: sans-serif;\"><p style=\"font-weight: 600;\">Login Details</p></td></tr>";
			
			$body .="<tr><td>E-mail  :</td><td>".$email."</td></tr>";
			$body .="<tr><td>Password:</td><td>".$password."</td></tr>";

			$body .="</table>";
			 $body .="<div style=\"width: 100%;\">";
			 
			 $body .= "<p style=\"text-align: justify;\">NOTE: Please do not reply to this e-mail. If you need to contact us, send an e-mail to our Customer Service at <a href=\"mailto:query@dressnroom.com\">query@dressnroom.com</a>.</p>";
			 $body .="<p></p>";
			 $body .="<p>Thanks & Regards</p>";
			 $body .="<p>DressNroom Team,<br>Email: <a href=\"mailto:info@dressnroom.com\">info@dressnroom.com</a></p></div>";
			 
			 $name="DressNroom App";
			 // Always set content-type when sending HTML email
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					// More headers
			$headers .= 'From: DressNroom <no-reply@dressnroom.com>'."\r\n";

			$mailsend = mail($email,$subject,$body,$headers);		 
			
			if($mailsend==1){
			  
			  $response["error"] = 0;
			  $response["success"] = 1;
			  $response["message"] = "Mail send Succesfully!";
			   
			}
			else{
			 
			 $response["error"] = 1;
			 $response["success"] = 0;
			 $response["message"] = "Mail not send Succesfully!";
			 
			}
		    }		  

else{
    $response["error"] = 1;
    $response["success"] = 0;
    $response["message"] = "Enter Correct Id! !";
    
}
echo json_encode($response);
?>
