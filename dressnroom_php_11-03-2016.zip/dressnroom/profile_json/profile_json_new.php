<?php
require_once("config.php");

//============================ For women profile======================================
  $get_result=mysql_query("select * from dr_map_2 where `gender`='2' and `cat_id` < 1 ");
  $detail=array();
  while($data=mysql_fetch_assoc($get_result)){
  // echo $data["name"]."<br>";
    $response=array();
    $subcat="";
    $response["id"]=$data["id"];
    $response["cat_name"]=$data["name"];
    
    
      $result=mysql_query("select * from dr_map_2 where `cat_id`='".$data["id"]."'");
       while($row=mysql_fetch_assoc($result)){
          $sub["id"]=$row['id'];
          $sub["subcat_name"]=$row['name'];
          $subcat[]=$sub;
       }
    $response["subcategory"]=$subcat;
    $detail[]=$response;
  }
//print_r($detail);

$json_data=json_encode($detail);
echo file_put_contents("json_new/women_profile.json", $json_data);

//============================ For men profile ======================================

$get_result=mysql_query("select * from dr_map_2 where `gender`='1' and `cat_id` < 1 ");
  $detail=array();
  while($data=mysql_fetch_assoc($get_result)){
  // echo $data["name"]."<br>";
    $response=array();
    $subcat="";
    $response["id"]=$data["id"];
    $response["cat_name"]=$data["name"];
    
    
      $result=mysql_query("select * from dr_map_2 where `cat_id`='".$data["id"]."'");
       while($row=mysql_fetch_assoc($result)){
          $sub["id"]=$row['id'];
          $sub["subcat_name"]=$row['name'];
          $subcat[]=$sub;
       }
    $response["subcategory"]=$subcat;
    $detail[]=$response;
  }
//print_r($detail);
$json_data=json_encode($detail);
echo file_put_contents("json_new/profile.json", $json_data);

//============================ For children profile ======================================
 $detail=array();
  $main_detail=array();
 $gen_id_arr=array("3"=>"boys_baby","4"=>"girls_baby","5"=>"boys_2to7","6"=>"girls_2to6","7"=>"boys_8to20","8"=>"girls_7to16");
 foreach($gen_id_arr as $k=>$v)
 {
   $detail=array();

      $get_result=mysql_query("select * from dr_map_2 where `gender`='".$k."' and `cat_id` < 1 ");
        $detail=array();;
        while($data=mysql_fetch_assoc($get_result)){
        // echo $data["name"]."<br>";
          $response=array();
          $subcat="";
          $response["id"]=$data["id"];
          $response["cat_name"]=$data["name"];
          
          
            $result=mysql_query("select * from dr_map_2 where `cat_id`='".$data["id"]."'");
             while($row=mysql_fetch_assoc($result)){
                $sub["id"]=$row['id'];
                $sub["subcat_name"]=$row['name'];
                $subcat[]=$sub;
             }
          $response["subcategory"]=$subcat;
          $detail[]=$response;
        }
   $main_detail[$v]=$detail;
   
 }     
//print_r($detail);
$json_data=json_encode($main_detail);
echo file_put_contents("json_new/child_profile.json", $json_data);

?>