<?php

$profile_data=array();
$gen_id=$_POST['tag'];
$user_id=$_POST['user_id'];
if($gen_id!=""){
    
    $profile_data['men'] = myhost.'profile_json/men_profile.json';
    $profile_data['women'] = myhost.'profile_json/women_profile.json';
    $profile_data['child'] = myhost.'profile_json/child_profile.json';


    if($user_id!="" && !empty($user_id))
   {
        if($_POST['gcmId']!="" && !empty($_POST['gcmId']))
	{
	    $qry ='UPDATE `registration` SET `login_status`= "1", `gcmId`="'.$_POST['gcmId'].'" WHERE `id`="'.$user_id.'"';   //Update GcmId
	    $updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
	}
        
        $qry ='SELECT * FROM `profile` WHERE `user_id`="'.$row1['id'].'"';
	$profile = mysqli_query($conn, $qry) or die (mysqli_error());
	$no_of_rows=mysqli_num_rows($profile);
	$profile_created="No";
	if($no_of_rows > 0)
	{
	    $profileArray1 = array();
	    
	    $profile_created="Yes";
	    foreach($profile as $profileid)
	    {
		$profileArray1[] = $profileid['gen_id'];
	    }
	    
	}
            $response["profile_created"] =$profile_created;
        if($no_of_rows > 0)
	{
	    $response["gen_id"] = $profileArray1;
	}
    }
    $response["error"]=0;
    $response["success"]=1;
    $response["category"]=$profile_data;
    $response["message"]="User Profile";
   
}
else{
    $response["error"]=1;
    $response["success"]=0;
    $response["category"]="";
    $response["message"]="Send Valid Data";
}

 
echo json_encode($response);

exit;
?>