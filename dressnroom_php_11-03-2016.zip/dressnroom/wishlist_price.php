<?php


ini_set('memory_limit', '-1');
include_once("simple_html_dom.php");
$wishlist_data=$_POST['wishlist_url_array'];
$wishlist_ids=array();
$wishlist_ids=json_decode($wishlist_data,true);
$data=array();


foreach($wishlist_ids as $row1)
{
    
        $qry ="SELECT * FROM `productinfo` WHERE `productId` = ".$row1["productId"];
        $query = mysqli_query($conn, $qry) or die (mysqli_error());
	 
	 while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC))
	    {
	       $sourceId = $row['sourceId'];
	       if($sourceId==1)
	       {
		  $pro['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $pro['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $pro['brand'] = 'macys';
	       } else{
		  $pro['brand'] = 'express';
	       }
	       $pro['productId'] = $row['productId'];
	       $pro['url'] = $row['productLink'];
	       $pro['img'] = $row['productImage'];
	       $pro['title'] = $row['productName'];
	       $pro['original_price'] = $row['productPrice'];
	      $pro['sale_price'] = $row['productSaleprice'];
	       
	    }
   

    $data[]=$pro;

}
$response["error"] = 0;
$response["success"] = 1;
$response['product_detail']=$data;
$response["message"] = "Select Record Successfully!";

echo json_encode($response);
?>