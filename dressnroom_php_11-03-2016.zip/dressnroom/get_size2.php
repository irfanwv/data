
<?php

$response=array();
$main_json_size=array();

$get_size=json_decode($_POST['cat_id_array'],true);

foreach($get_size['selected_items'] as $value)
{
    $size_info="";
    $color_info="";
    $main_data="";
    $cat_id=$value['cat_id'];
    $main_data['main_is_selected']=$value['main_is_selected'];
    $main_data['cat_id']=$cat_id;
    $main_data['cat_name']=$value['cat_name'];   
    $main_data['sub_cat_array']=array();
    
    if(!empty($value["sub_cat_array"]) && $value["sub_cat_array"]!=null && $value["sub_cat_array"]!='')
    {
        $sub_cat_id=array();
        $sub_cat_id_str='';
        foreach($value["sub_cat_array"] as $subvalue)
        {
             $sub_cat_id[]=$subvalue['sub_cat_id'];             
             $sub_cat_id_str=implode("','",$sub_cat_id);             
        }
        if($value["main_is_selected"]=="true")
        {
            if(!empty($sub_cat_id))
            {                
                //===================size========================================================
               

              foreach($value["sub_cat_array"] as $subvalue)
             {  
              
              $qry = "SELECT DISTINCT (AttributeValue) as sizeName FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE  proatt.AttributeName = 'Size' AND proinfo.categoryId =".$subvalue['sub_cat_id'];
                
                 $sub_results = mysqli_query($conn, $qry) or die (mysqli_error());
                 
                if(mysqli_num_rows($sub_results) > 0)
                {
                    while($data = mysqli_fetch_assoc($sub_results))
                    {
                        $size_info[]=$data;
                        
                    }  
                }
                
                
             }
             

                $qry = "SELECT DISTINCT (AttributeValue) as colorName, colorImage as colorCode FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE  proatt.AttributeName = 'Color' AND proinfo.categoryId =".$subvalue['sub_cat_id'];
               
                 $color_results = mysqli_query($conn, $qry) or die (mysqli_error());    
                
                if(mysqli_num_rows($color_results) > 0)
                {
                    while($data1 = mysqli_fetch_assoc($color_results))
                    {                    
                        $color_info[]=$data1;                   
                    }                   
                }   
               
            }
            //===========================================
            $main_data['sub_cat_array']=$value["sub_cat_array"];
            if($color_info!=''){
                $main_data['colorArray']=$color_info;
            }
            if($size_info!=''){
                $main_data['sizeArray']=$size_info;
            }
            
            //===========================================            
        }
        else
        {
            
            if(!empty($sub_cat_id))
            {
                $subcatMainArray=array();
                   $jjj=0;     
                foreach($value["sub_cat_array"] as $subvalue1)
                { 
                    $subcatArray=array();
                    $subcatArray['sub_cat_id']=$subvalue1['sub_cat_id'];
                    $subcatArray['sub_cat_name']=$subvalue1['sub_cat_name'];
                    $sub_cat_id=$subvalue1['sub_cat_id'];
                    //===============================Size=========================================
                    
                    $qry = "SELECT DISTINCT (AttributeValue) as sizeName FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE  proatt.AttributeName = 'Size' AND proinfo.categoryId =".$subvalue1['sub_cat_id'];
                   
                               $sub_results = mysqli_query($conn, $qry) or die (mysqli_error());  
                    if(mysqli_num_rows($sub_results) > 0)
                    {
                      while($data = mysqli_fetch_assoc($sub_results))
                       {
                           
                           
                             $size_info[]=$data;
                        }
                       
                    } else
                    {
                        unset($size_info);
                        
                    }
                    
                    //====================color========================
                    
                    $qry = "SELECT DISTINCT (AttributeValue) as colorName, colorImage as colorCode FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE  proatt.AttributeName = 'Color' AND proinfo.categoryId =".$subvalue1['sub_cat_id'];
                    
                     $color_results = mysqli_query($conn, $qry) or die (mysqli_error());
                      
                    if(mysqli_num_rows($color_results) > 0)
                    {   
                        while($data1 = mysqli_fetch_assoc($color_results))
                        {                              
                            $color_info[] = $data1;
                           
                        }
                    }
                    else
                    {
                        unset($color_info);
                    }
                     
                                   
                    if($size_info!=''){
                        $subcatArray['sizeArray']=$size_info;
                        unset($size_info);
                    }
                    else
                    {
                        $subcatArray['sizeArray']=array(); 
                    }
                    if($color_info!=''){
                        $subcatArray['colorArray']=$color_info;
                        unset($color_info);
                    }
                    else
                    {
                        $subcatArray['colorArray']=array(); 
                    }
                    $subcatMainArray[]=$subcatArray;
                } 
                //===========================================
                $main_data['sub_cat_array']=$subcatMainArray;
               
                //===========================================
            }            
        } 
    }
    else
    {
        
        $cat_id=$value['cat_id'];
        //===============================Size=========================================
      
       
        $qry = "SELECT DISTINCT (AttributeValue) as sizeName FROM `productAttribute` AS proatt INNER JOIN `productinfo` as proinfo ON proatt.productId = proinfo.productId WHERE  proatt.AttributeName = 'Size' AND proinfo.categoryId =".$cat_id;
        
        //if(mysqli_num_rows($sub_results) > 0)
        {
          while($data = mysqli_fetch_assoc($sub_results)){
               
                //$size_info[]=$data['size_name'];
                 $size_info[]=$data;
            }  
        }
       
        if($size_info!='')
        {
            $subcatArray['sizeArray']=$size_info;
        }
       
        //===========================================
    }

    $main_json_size[]=$main_data;
}
//---------------------------------------------

if(count($main_data) > 0){
   $response['error']=0;
   $response['success']=1;
   $response['selected_items']=$main_json_size;
  // $response['color_list']=$main_json;
   $response['message']="Select size successfully";
   
}
else{
    $response['error']=1;
    $response['success']=0;
    $response['selected_items']="";
    $response['message']=" size not available";
}

/*print response in json format*/
echo json_encode($response);

?>