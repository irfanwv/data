<?php /* Start GAP.com*/
	 
include 'db_conf.php';
date_default_timezone_set("UTC");
$handle = fopen('php://input','r');
$jsonInput = fgets($handle);
$decoded = json_decode($jsonInput,true);

    include_once("snoopy.class.php");
    include_once("htmlsql.class.php");
    $imgLink = array();
    $price = array();
    $del = array();
    $i=0;
    $sourceId = 2;
    $qry11 = '';
    $qry12 = '';
    $productCatid = $_GET['categoryId'];
    $genderId = $_GET['genId'];
    $update = $_GET['update'];
    
    if(isset($_GET['filter']) && $_GET['filter']=="discount" )
{
   $filter="Yes";
} else
{
    $filter="NO";
}
    if($update=='yes'){
	
    
    $qry = "SELECT * FROM `categoryMapping` WHERE categoryId ='".$productCatid."' AND `sourceId` = '2'"; // sourceId [Bonton =1, Gap=4]
    $results = mysqli_query($conn, $qry);
    
    $dat = mysqli_fetch_assoc($results);
    $link = "http://www.gap.com/".$dat["categoryUrl"];

   if($dat["categoryUrl"] != "")
   {
    $wsql = new htmlsql();
    

    if (!$wsql->connect('url', $link)){
        print 'Error while connecting: ' . $wsql->error;
        exit;
    }
    
    
    
    if (!$wsql->query('SELECT * FROM * WHERE $class == "brand1 productCatItem"')){
        print "Query error: " . $wsql->error; 
        exit;
    }

    // show results:
    foreach($wsql->fetch_array() as $row)
    {
        $data = stristr($row['text'], 'src="'); // Stripping all data from before $start
        $data = substr($data, strlen('src="'));  // Stripping $start
        $stop = stripos($data, '/>');   // Getting the position of the $end of the data to scrape
        $img = substr($data, 0, $stop);    // Stripping all data from after and including the $end of the data to scrape
        $img = str_replace('"', '', $img);
        $string  = str_replace(' ', '', $img);
        $imgLink[] = preg_replace('/\s+/', '', $string);
    }
    
    
   if (!$wsql->query('SELECT * FROM * WHERE $class == "priceDisplay" || $class == "priceDisplaySale"')){
        print "Query error: " . $wsql->error; 
        exit;
    }

    foreach($wsql->fetch_array() as $row)
    {

      $price[] = $row['text'];
    }
    
     if (!$wsql->query('SELECT * FROM * WHERE $class == "productItemName"')){
        print "Query error: " . $wsql->error; 
        exit;
    }
    
    foreach($wsql->fetch_array() as $row){

        $productname = $row['text'];
        $productlink = $row['href'];
        $priceArray=explode("$",$price[$i]);
        $productprice=trim($priceArray[1]);
        $productimage = 'http://www.gap.com'.$imgLink[$i];
        
        $productsaleprice = '';
        $dataimg = $row['href'];
        $startimg = 'pid=';
        $endimg = '&vid=1';
        $dataimg = stristr($dataimg, $startimg); // Stripping all data from before $start
        $dataimg = substr($dataimg, strlen($startimg));  // Stripping $start
        $stop = stripos($dataimg, $endimg);   // Getting the position of the $end of the data to scrape
        $sourcePid = substr($dataimg, 0, $stop);
        
        $qry = "SELECT `sourceProductId` FROM `productinfo` WHERE `sourceProductId`=".$sourcePid;
        $result = mysqli_query($conn, $qry);
        $retrive  = mysqli_fetch_row($result);
        if ($retrive[0] == NULL)
        {	if ($productsaleprice == NULL || $productsaleprice == "" || $productsaleprice == 00.00)
	       {
		  $productsaleprice = $productprice;
	       }
            $qry1 = 'INSERT INTO `productinfo`( `productName`, `productPrice`, `productSaleprice`, `productImage`, `productLink`,`categoryId`, `sourceProductId`, `sourceId`)';
            $qry1 .= 'VALUES ("'.$productname.'","'.$productprice.'","'.$productsaleprice.'","'.$productimage.'","'.$productlink.'","'.$productCatid.'","'.$sourcePid.'","'.$sourceId.'");';
            $del[] = $sourcePid;
	    //echo $qry1;
	    $result11 = mysqli_query($conn, $qry1);
            
        }
         else
         {	if ($productsaleprice == NULL || $productsaleprice == "" || $productsaleprice == 00.00)
	       { $productsaleprice = $productprice;
	       }
            $qry2 ='UPDATE `productinfo` SET `productName`="'.$productname.'",`productPrice`="'.$productprice.'",`productSaleprice`="'.$productsaleprice.'",';
            $qry2 .='`productImage`="'.$productimage.'",`productLink`="'.$productlink.'" WHERE `sourceProductId`='.$sourcePid.';';
            
            $result12 = mysqli_query($conn, $qry2);
            $del[] = $sourcePid;
         }
         
      $i++;
    }
   
    exit;
    $dif = array_unique(array_diff($array1, $del));
    foreach ($dif as $val)
{
   $qry3 = "DELETE FROM `productinfo` WHERE `sourceProductId`='".$val."' AND `sourceId`='2';";
   $result3 = mysqli_query($conn, $qry3);
}
    
 date_default_timezone_set("UTC");
    //$result1 = mysqli_multi_query($conn, $qry1);
    $qry2 = "UPDATE `timetrigger` SET `lastUpdate`='".time()."',`sourceId`='1' WHERE `categoryId` = '".$productCatid."';";
   // $qry2 .="SELECT * FROM `productinfo` WHERE `categoryId` = '".$productCatid."' ORDER BY productId DESC LIMIT 40;";
    $result2 = mysqli_query($conn, $qry2);
   }
            
  // echo $qry2.':'.$result2; exit;
  }
  unset($data);
  $data=array();

 $qryy ="SELECT * FROM `productinfo` WHERE `categoryId` = '".$productCatid."' ORDER BY productId DESC LIMIT 100";
	                                                                                                    
	 $result21 = mysqli_query($conn, $qryy) or die (mysqli_error());
	 foreach($result21 as $row1)
	    {
	       $sourceId = $row1['sourceId'];
	       if($sourceId==1)
	       {
		  $info['brand'] = 'bonton';
	       } elseif ($sourceId==2){
		  $info['brand'] = 'gap';		  
	       } elseif ($sourceId==3){
		  $info['brand'] = 'macys';
	       } else{
		  $info['brand'] = 'express';
	       }
	       $info['productId'] = $row1['productId'];
	       $info['url'] = $row1['productLink'];
	       $info['img'] = $row1['productImage'];
	       $info['title'] = $row1['productName'];
	       $info['original_price'] = $row1['productPrice'];
	       $info['sale_price'] = $row1['productSaleprice'];
	       
	       $data[]=$info;
	    }

	    
    $tocat_record=count($data);
if($tocat_record > 0)
{
     // shuffle($data);
     function cmp($a, $b)
      {
	  if ($a["sale_price"] == $b["sale_price"]) {
	      return 0;
	  }
	  return ($a["sale_price"] < $b["sale_price"]) ? -1 : 1;
      }
      
      function sort_discount($a, $b)
      {
	  if ($a["discount_off"] == $b["discount_off"]) {
	      return 0;
	  }
	  return ($a["discount_off"] > $b["discount_off"]) ? -1 : 1;
      }

      usort($data,"cmp");
      
      if($filter=="Yes"){
	  usort($data,"sort_discount");
      }
     
      
      $i=1;
      $tot=0;
      $file_url="";
      $url_data=array();
      foreach(array_chunk($data, 30) as $dataresult ) {
	 if($i > 1){
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $file_url["url"]=myhost."temp/".$user_id."_".$i.".json";
	    $url_data[]=$file_url;
	 }else{
	    file_put_contents("temp/".$user_id."_".$i.".json", json_encode($dataresult));
	    $datas=$dataresult;
	 }
	 $tot++;
	 $i++;
      }
      $response["error"] = 0;
      $response["success"] = 1;
      $response["total_record"] = $tocat_record;
      $response["host_url"]=myhost."temp/";
      $response["total_page"]=$tot;
      $response["files"] = $url_data;
      $response['product']=$datas;     
      $response["message"] = "Select Record Successfully!";
}
else{
     $response["error"] = 1;
     $response["success"] = 0;    
     $response["message"] = "Product Not found";
   
}

echo json_encode($response);
	
	 /*End Gap.com*/
         ?>