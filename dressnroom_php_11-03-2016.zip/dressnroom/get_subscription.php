<?php


$user_id=$_POST['user_id'];

	
	$qry ="SELECT * FROM `userSubscription` WHERE `userId`='".$user_id."'";
	
	$get_res = mysqli_query($conn, $qry) or die (mysqli_error());
	$no_of_row=mysqli_num_rows($get_res);
	$gcmRow=mysqli_fetch_row($get_res);
	$subscriptionDate = date('Y-m-d H:i:s');
	
	if($no_of_row > 0)
	{
            $datetime1 = new DateTime();
                    
            $response['subscription_type']= $gcmRow[2];
            if($gcmRow[2] == 'TYPE1')
	    {
		
                  $exp1 = date('Y-m-d', strtotime('+30 day', strtotime($gcmRow[3])));
                  $exp2 = date('Y-m-d', strtotime('-7 day', strtotime($exp1)));
                    $datetime2 = new DateTime($exp1);
                    $interval = $datetime1->diff($datetime2);
                    $response['expriration_daysleft'] = $interval->d;
               if(date('Y-m-d')>$exp2 && date('Y-m-d')<$exp1)
               {
                    $response['is_expired']= 'false';
               } elseif(date('Y-m-d')<$exp1)
               {
                    $response['is_expired']= 'false';
               }
               else
               {
                    $response['is_expired']= 'true';
               }
	    }elseif($gcmRow[2] == 'TYPE2')
	    {
		
                  $exp1 = date('Y-m-d', strtotime('+30 day', strtotime($gcmRow[3])));
                  $exp2 = date('Y-m-d', strtotime('-7 day', strtotime($exp1)));
                    $datetime2 = new DateTime($exp1);
                    $interval = $datetime1->diff($datetime2);
                    $response['expriration_daysleft'] = $interval->d;
               if(date('Y-m-d')>$exp2 && date('Y-m-d')<$exp1)
               {
                    $response['is_expired']= 'true';
               }
               else
               {
                    $response['is_expired']= 'false';
               }
	    }elseif($gcmRow[2] == 'TYPE3')
	    {
		
                  $exp1 = date('Y-m-d', strtotime('+365 day', strtotime($gcmRow[3])));
                  $exp2 = date('Y-m-d', strtotime('-7 day', strtotime($exp1)));
                    $datetime2 = new DateTime($exp1);
                    $interval = $datetime1->diff($datetime2);
                    if($interval->m){
                     $now = time(); // or your date as well
                    $your_date = strtotime($exp1);
                    $datediff =  $your_date-$now;
                    $response['expriration_daysleft'] = floor($datediff/(60*60*24));
                    } else
                    {
                       $response['expriration_daysleft'] = $interval->d; 
                    }
     
                    
               if(date('Y-m-d')>$exp2 && date('Y-m-d')<$exp1)
               {
                    $response['is_expired']= 'true';
               }
               else
               {
                    $response['is_expired']= 'false';
               }
	    }
		
	    $response["error"] = 0;
	    $response["success"] = 1;
	    $response["message"] = "Subscription Details!";
        }  else
        {
            $response["error"] = 1;
	    $response["success"] = 0;
	    $response["message"] = "Subscription Details Not Found!";
        }

/*print response in json format*/
echo json_encode($response);


?>