<?php

$user_id=$_POST['user_id'];
$gen_id=$_POST['gen_id'];
$profile=$_POST['profile_data'];

	
	$qry ="SELECT * FROM `profile` WHERE `user_id`='$user_id' and `gen_id`='$gen_id'";
	$get_res = mysqli_query($conn, $qry) or die (mysqli_error());
	$no_of_row=mysqli_num_rows($get_res);
	if($no_of_row > 0)
	{
		
		$qry ="UPDATE `profile` SET `profile_data`='".$profile."' WHERE `user_id`='".$user_id."' and `gen_id`='".$gen_id."'";
		$updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
                if($updatedata){
                    $response['error']= 0 ;
                    $response['success']= 1 ;
                    $response['message']= "Update Successfully!" ;        
                }

	}else
	{
		$qry ="INSERT INTO `profile`(`user_id`, `gen_id`, `profile_data`) VALUES ('".$user_id."','".$gen_id."','".$profile."')";
		$result = mysqli_query($conn, $qry) or die (mysqli_error());
		
		if($result!=false){
                    $response["error"] = 0;
		    $response["success"] = 1;
		    $response["message"] = "Profile Create Successfully!";
                    
                }else{
                    $response["error"] = 1;
		    $response["success"] = 0;
		    $response["message"] = "Insertion fail!";
                }



        }
/*print response in json format*/
echo json_encode($response);



?>