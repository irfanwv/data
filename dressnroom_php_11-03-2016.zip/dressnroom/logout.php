<?php

if($_POST['user_id']!="" && !empty($_POST['user_id']))
{

    $qry ='SELECT * FROM `registration` WHERE `id`="'.$_POST['user_id'].'"';
    $log = mysqli_query($conn, $qry) or die (mysqli_error());
    $no_of_row=mysqli_num_rows($log);


    if($no_of_row==1)
    {
	
	$qry ='UPDATE `registration` SET `login_status`= "", `gcmId`="" WHERE `id`="'.$_POST['user_id'].'"';   //Update GcmId
	$updatedata = mysqli_query($conn, $qry) or die (mysqli_error());
	 
	$response["error"] = 0;
        $response["success"] = 1;
	$response["user_id"] = $_POST['user_id'];	
        $response["message"] = "You Logged Out Successfully";
    }    
    else
    {
	$response["error"] = 1;
	$response["success"] = 0;
	$response["message"] = "Invalid Username/Password";
    }
}
else
{
    /*print error message*/ 
    $response["error"] = 1;
    $response["success"] = 0;
    $response["message"] = "Send Proper Data!";
}

echo json_encode($response);
?>