<?php


ini_set('memory_limit', '-1');

include_once("simple_html_dom.php");
$profile_data=array();
$gen_id=$_POST['gen_id']; //2
$user_id=$_POST['user_id']; //41
$data=array();
  
   $qry ="SELECT * FROM `profile` WHERE `gen_id`='$gen_id' and `user_id`= '$user_id'";
   $results = mysqli_query($conn, $qry) or die (mysqli_error());
   $count = mysqli_num_rows($results);
   	
   if($userdata=mysqli_fetch_assoc($results))
   {
      $profile=$userdata['profile_data'];
      $product_ids=json_decode($profile,true);
      $gen_id=$_POST['gen_id'];
      
      foreach($product_ids as $values)
      {
         $p_id=$values["id"];
         $p_size=$values["size"];
         
	 $qryy ="SELECT * FROM `categoryinfo` WHERE `categoryId`='$p_id' AND `genderId`='$gen_id'";
	 $results = mysqli_query($conn, $qryy) or die (mysqli_error());
	 $data3=mysqli_fetch_assoc($results);
	 
         $gender=$data3['genderId'];
         
	 $product_pic=$data3["categoryPic"];
         $name=$data3["categoryName"];
	 	 
         if($gender==1)        
         {   
            $gender="men";
         }
         elseif($gender==2)
         {
            $gender="women";
         }
         else
         {
            $gender="baby-kids";
         }
       	   
	    $info=array();
	    $info['product_id']=$p_id;
	    $info['size_id']=$p_size;
	    $info['brand']="Bonton";
	    $info['name']=$name;
	    $info['url']="";
	    $info['img']=$product_pic;
	    $info['title']="";
	    
	    $info['original_price']="";
	    $info['sale_price']="";	    
	    $data[]=$info;

      }
       
      $response["profile"]=$data;
      $response["error"]=0;
      $response["success"]=1;
      $response["message"]="Your profile";
        
   }
   else
   {       
      $response["error"]=1;
      $response["success"]=0;
      $response["message"]="List not found";

   }

/*print response in json format*/
echo json_encode($response);
?>